from build_graph import build_graph, activations
from local_derivatives import compute_local_derivatives

if __name__ == "__main__":
    # Take inputs just once
    x = float(input("Enter input value x: "))
    y_true = float(input("Enter true output y: "))
    num_layers = int(input("Enter number of layers: "))

    layer_weights = []
    layer_biases = []
    layer_act_funcs = []   # actual functions
    layer_act_names = []   # string names

    for i in range(num_layers):
        w = float(input(f"Enter weight for layer {i+1}: "))
        b = float(input(f"Enter bias for layer {i+1}: "))
        act = input(f"Enter activation (relu/sigmoid/tanh/softmax/id) for layer {i+1}: ").strip().lower()

        layer_weights.append(w)
        layer_biases.append(b)
        layer_act_funcs.append(activations[act])  # store function
        layer_act_names.append(act)               # store name

    # Forward pass
    values, G = build_graph(x, y_true, num_layers, layer_weights, layer_biases, layer_act_funcs, plot=True)

    # Backward (local derivatives)
    derivs = compute_local_derivatives(values, layer_weights, layer_biases, layer_act_funcs, layer_act_names, y_true)

    print("\nForward values:")
    for k, v in values.items():
        print(f"{k}: {v}")

    print("\nLocal derivatives:")
    for k, v in derivs.items():
        print(f"{k}: {v}")

