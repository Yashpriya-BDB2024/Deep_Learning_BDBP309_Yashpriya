# Implement a forward pass of a single layer neural network in Python. Input features = 3, output = 1 (scalar value).
# You are allowed to use PyTorch functions.

import torch
import torch.nn as nn

def forward_pass():
    # Single linear layer: input features = 3, output = 1
    layer = nn.Linear(3, 1)

    # Example input (batch size = 1, 3 features)
    x = torch.tensor([[1.0, 2.0, 3.0]])

    # Forward pass
    output = layer(x)
    return output
