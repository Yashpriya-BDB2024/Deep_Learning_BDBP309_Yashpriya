import torch
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch.nn.functional as F
from PIL import Image
from torchvision import datasets, transforms
from torch import nn, optim
import torch.nn as nN
import torch.optim as optIM
from torch.utils.data import DataLoader,TensorDataset, random_split, ConcatDataset
from sklearn.datasets import make_circles, make_classification
from sklearn.metrics import accuracy_score
from sklearn.svm import LinearSVC, LinearSVR, SVR, SVC
from torch.optim import SGD, Adam, RMSprop, Adagrad
from scipy.special.cython_special import hyp1f1
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from torchvision.io import read_image
from torchvision.transforms import ToTensor
from torchvision import datasets, transforms, models
import seaborn as sns
from torchvision.models import ResNet50_Weights
import torchvision
from torch.nn.utils.rnn import pad_sequence
import string
from hyperopt import hp, fmin, tpe, Trials, STATUS_OK
from sklearn.decomposition import PCA
from pathlib import Path
import sys

#
# datasets_train = {
#     "MNIST": torchvision.datasets.MNIST(root="./data", train=True, download=True),
#     "FashionMNIST": torchvision.datasets.FashionMNIST(root="./data", train=True, download=True),
#     "CIFAR10": torchvision.datasets.CIFAR10(root="./data", train=True, download=True),
#     "CIFAR100": torchvision.datasets.CIFAR100(root="./data", train=True, download=True)
# }
#
# datasets_test = {
#     "MNIST": torchvision.datasets.MNIST(root="./data", train=False, download=True),
#     "FashionMNIST": torchvision.datasets.FashionMNIST(root="./data", train=False, download=True),
#     "CIFAR10": torchvision.datasets.CIFAR10(root="./data", train=False, download=True),
#     "CIFAR100": torchvision.datasets.CIFAR100(root="./data", train=False, download=True)
# }