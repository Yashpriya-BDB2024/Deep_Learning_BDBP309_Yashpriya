import numpy as np

# Layers
W1 = np.array([[2.0, -1.0],
               [0.5,  3.0]])
b1 = np.array([1.0, -2.0])

W2 = np.array([[1.0, 2.0]])
b2 = np.array([0.5])

# Activations
def identity(z): return z
def relu(z): return np.maximum(0, z)

# Function to compute two-layer output
def two_layer(x, activation):
    z1 = W1 @ x + b1
    h1 = activation(z1)
    z2 = W2 @ h1 + b2
    return activation(z2)

# Function for equivalent single linear layer
W_combined = W2 @ W1
b_combined = W2 @ b1 + b2
def single_layer(x):
    return W_combined @ x + b_combined

# ---------------- Identity Case ----------------
print("=== Identity Activation ===")
for x in [np.array([1.0, 2.0]), np.array([-3.0, 1.0]), np.array([0.5, -2.0])]:
    y_two = two_layer(x, identity)
    y_single = single_layer(x)
    print(f"x={x} -> two_layer={y_two}, single_layer={y_single}")

# ---------------- ReLU Case ----------------
print("\n=== ReLU Activation ===")
for x in [np.array([1.0, 2.0]), np.array([-3.0, 1.0]), np.array([0.5, -2.0])]:
    y_two = two_layer(x, relu)
    y_single = single_layer(x)
    print(f"x={x} -> two_layer(ReLU)={y_two}, single_layer={y_single}")
