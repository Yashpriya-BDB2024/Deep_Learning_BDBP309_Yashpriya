import numpy as np
import matplotlib.pyplot as plt


# ----------------- Activation Functions -----------------
def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def sigmoid_derivative(a):
    return a * (1 - a)


def relu(x):
    return np.maximum(0, x)


def relu_derivative(a):
    return np.where(a > 0, 1, 0)

def identity(x):
    return x

def identity_derivative(a):
    return np.ones_like(a)

def softmax(x):
    e_x = np.exp(x - np.max(x))
    return e_x / np.sum(e_x)

def forward_pass(x, weights, biases, activations, use_bias):
    a_list = [x.reshape(1, -1)]
    z_list = []

    for i in range(len(weights)):
        z = np.dot(a_list[-1], weights[i].T)
        if use_bias[i]:
            z += biases[i]
        z_list.append(z)

        act = activations[i].lower()
        if act == "sigmoid":
            a = sigmoid(z)
        elif act == "relu":
            a = relu(z)
        elif act == "identity":
            a = identity(z)
        elif act == "softmax":
            a = softmax(z)
        else:
            raise ValueError("Unknown activation")
        a_list.append(a)
    return a_list, z_list


def backward_pass(a_list, z_list, weights, biases, activations, y_true, use_bias):
    L = len(weights)
    grads_w = [np.zeros_like(w) for w in weights]
    grads_b = [np.zeros_like(b) if ub else None for b, ub in zip(biases, use_bias)]

    # Output layer delta
    delta = a_list[-1] - y_true.reshape(1, -1)
    act = activations[-1].lower()
    if act == "sigmoid":
        delta *= sigmoid_derivative(a_list[-1])
    elif act == "relu":
        delta *= relu_derivative(a_list[-1])
    elif act == "identity":
        delta *= identity_derivative(a_list[-1])
    elif act == "softmax":
        delta = delta  # cross-entropy with softmax

    for i in reversed(range(L)):
        grads_w[i] = np.dot(delta.T, a_list[i])
        if use_bias[i]:
            grads_b[i] = delta
        if i != 0:
            act_prev = activations[i - 1].lower()
            if act_prev == "sigmoid":
                deriv = sigmoid_derivative(a_list[i])
            elif act_prev == "relu":
                deriv = relu_derivative(a_list[i])
            elif act_prev == "identity":
                deriv = identity_derivative(a_list[i])
            else:
                deriv = a_list[i]
            delta = np.dot(delta, weights[i]) * deriv
    return grads_w, grads_b

def train(X, Y, layer_sizes, activations, use_bias, epochs=1000, lr=0.1):
    weights = []
    biases = []

    # Ask user for manual/random initialization
    for i in range(len(layer_sizes) - 1):
        # Weights
        choice = input(f"Layer {i + 1}: Enter weights manually? (Y/N): ").lower()
        if choice == 'y':
            vals = list(map(float, input(f"Enter {layer_sizes[i + 1] * layer_sizes[i]} values row-wise: ").split()))
            weights.append(np.array(vals).reshape(layer_sizes[i + 1], layer_sizes[i]))
        else:
            weights.append(np.random.randn(layer_sizes[i + 1], layer_sizes[i]) * 0.01)
        # Biases
        if use_bias[i]:
            choice = input(f"Layer {i + 1}: Enter biases manually? (Y/N): ").lower()
            if choice == 'y':
                vals = list(map(float, input(f"Enter {layer_sizes[i + 1]} bias values: ").split()))
                biases.append(np.array(vals).reshape(1, layer_sizes[i + 1]))
            else:
                biases.append(np.zeros((1, layer_sizes[i + 1])))
        else:
            biases.append(None)

    losses = []
    for epoch in range(epochs):
        total_loss = 0
        for x, y_true in zip(X, Y):
            a_list, z_list = forward_pass(x, weights, biases, activations, use_bias)
            loss = np.sum((a_list[-1] - y_true.reshape(1, -1)) ** 2) / 2
            total_loss += loss

            grads_w, grads_b = backward_pass(a_list, z_list, weights, biases, activations, y_true, use_bias)
            # Update weights and biases
            for i in range(len(weights)):
                weights[i] -= lr * grads_w[i]
                if use_bias[i]:
                    biases[i] -= lr * grads_b[i]
        avg_loss = total_loss / len(X)
        losses.append(avg_loss)
        if (epoch + 1) % 100 == 0 or epoch == 0:
            print(f"Epoch {epoch + 1}, Loss: {avg_loss:.6f}")

    # Print final gradients
    print("\nFinal gradients per layer:")
    for i in range(len(weights)):
        print(f"Layer {i + 1} weight gradients (dW):\n{grads_w[i]}")
        if use_bias[i]:
            print(f"Layer {i + 1} bias gradients (db):\n{grads_b[i]}")
    return weights, biases, losses


# ----------------- Prediction -----------------
def predict(X, weights, biases, activations, use_bias):
    preds = []
    for x in X:
        a_list, _ = forward_pass(x, weights, biases, activations, use_bias)
        preds.append(a_list[-1])
    return np.array(preds)

if __name__ == "__main__":
    X = np.array([[0, 0, 1],
                  [0, 1, 1],
                  [1, 1, 1],
                  [1, 0, 1]])
    Y = np.array([[0], [1], [1], [0]])

    # Network definition
    layer_sizes = [3, 2, 1]  # 3 input, 2 hidden, 1 output
    activations = ["relu", "sigmoid"]  # hidden relu, output sigmoid
    use_bias = [True, True]

    weights, biases, losses = train(X, Y, layer_sizes, activations, use_bias, epochs=500, lr=0.1)
    preds = predict(X, weights, biases, activations, use_bias)
    print("\nPredictions:\n", preds)

    plt.plot(losses)
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title("Training Loss Over Epochs")
    plt.show()
