import torch
import torchvision
import torchvision.transforms as transforms

# Load CIFAR10 as tensors (without normalization)
transform = transforms.ToTensor()
dataset = torchvision.datasets.CIFAR10(root='./data', train=True,
                                       download=True, transform=transform)

# Stack all images into a single tensor
loader = torch.utils.data.DataLoader(dataset, batch_size=len(dataset), shuffle=False)
images, _ = next(iter(loader))   # all training images in one batch

# images shape = (50000, 3, 32, 32)
mean = images.mean(dim=[0,2,3])   # mean over N, H, W
std = images.std(dim=[0,2,3])     # std over N, H, W

print("Mean:", mean)
print("Std:", std)
