import torch
import torchvision
import torchvision.transforms as transforms

def load_cifar10():
    transform = transforms.Compose([
        transforms.ToTensor(),   # Converts to tensor in range [0,1]
    ])

    train_set = torchvision.datasets.CIFAR10(root='./data', train=True,
                                             download=True, transform=transform)
    test_set = torchvision.datasets.CIFAR10(root='./data', train=False,
                                            download=True, transform=transform)

    train_loader = torch.utils.data.DataLoader(train_set, batch_size=64, shuffle=True)
    test_loader = torch.utils.data.DataLoader(test_set, batch_size=64, shuffle=False)

    return train_loader, test_loader


# --- Main Execution ---
train_loader, test_loader = load_cifar10()

# Take one batch
images, labels = next(iter(train_loader))

print("Batch of images shape:", images.shape)   # (64, 3, 32, 32)
print("Batch of labels shape:", labels.shape)   # (64,)

print("Min pixel value:", images.min().item())  # Expect 0.0
print("Max pixel value:", images.max().item())  # Expect 1.0

print("First 5 labels:", labels[:5])
