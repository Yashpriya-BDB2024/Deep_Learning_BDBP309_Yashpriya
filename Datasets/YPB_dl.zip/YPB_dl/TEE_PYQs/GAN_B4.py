
# B4. Train a GAN model for a simulated dataset of random noise samples that resemble a 1D Gaussian distribution.
# The generator should learn to produce data samples that resemble real samples from a Gaussian distribution, and
# the discriminator will learn to distinguish between real and fake samples.
# You can use the following assumptions and hyperparameters in your implementation:
# The generator should have Linear – ReLU – Linear – ReLU – Linear layers.
# The discriminator should have Linear – LeakyReLU – Linear – LeakyReLU – Linear – Sigmoid.
# Plot the real data and the generated data for visualization.

import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import numpy as np

# Hyperparameters (given in the question)
latent_dim = 10   # size of random noise vector input to Generator
hidden_dim = 128   # number of neurons in hidden layers
output_dim = 1   # 1 (because each data sample is a single number: 1D Gaussian)
batch_size = 64
num_epochs = 5000
learning_rate = 0.0002

# Function to sample from real 1D Gaussian distribution (N(0,1))
def sample_real(batch_size):
    return torch.randn(batch_size, output_dim)

class Generator(nn.Module):
    def __init__(self):
        super(Generator, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)   # Outputs a fake data point.
        )
    # Defines how input flows via Generator.
    def forward(self, z):   # z is a random noise.
        return self.net(z)   # Generated data

class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(output_dim, hidden_dim),
            nn.LeakyReLU(0.2),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU(0.2),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()    # Outputs a no. b/w 0 (fake) and 1 (real).
        )
    def forward(self, x):
        return self.net(x)

def main():
    G = Generator()
    D = Discriminator()
    criterion = nn.BCELoss()    # Binary cross entropy (real/fake classification)
    # Adam optimizer adjusts weights of each network.
    optimizer_G = optim.Adam(G.parameters(), lr=learning_rate)
    optimizer_D = optim.Adam(D.parameters(), lr=learning_rate)

    for epoch in range(num_epochs):
    # Train Discriminator
        real_data = sample_real(batch_size)   # Sample real gaussian data
        real_labels = torch.ones(batch_size, 1)    # Label real data as 1
        z = torch.randn(batch_size, latent_dim)   # Sample new noise for Generator
        fake_data = G(z)   # Create fake samples
        fake_labels = torch.zeros(batch_size, 1)   # Label fake data as 0
        loss_real = criterion(D(real_data), real_labels)   # Compare Discriminator predictions with correct labels
        loss_fake = criterion(D(fake_data.detach()), fake_labels)   # detach() - prevents gradients from flowing back to Generator
        D_loss = loss_real + loss_fake
        optimizer_D.zero_grad()
        D_loss.backward()
        optimizer_D.step()   # Update D weights

        # Train Generator
        z = torch.randn(batch_size, latent_dim)   # Create new fake samples
        generated = G(z)
        G_loss = criterion(D(generated), real_labels)   # Generator wants D to think fake as real.
        optimizer_G.zero_grad()
        G_loss.backward()
        optimizer_G.step()    # Update G weights

        if (epoch + 1) % 500 == 0:
            print(f"Epoch {epoch+1}/{num_epochs}  D_loss: {D_loss.item():.4f}  G_loss: {G_loss.item():.4f}")

    # Visualization
    real_samples = sample_real(1000).detach().numpy()    # 1000 real data points
    z = torch.randn(1000, latent_dim)    # 1000 noise samples
    fake_samples = G(z).detach().numpy()    # 1000 fake data points

    plt.hist(real_samples, bins=50, alpha=0.5, label="Real Data")
    plt.hist(fake_samples, bins=50, alpha=0.5, label="Generated Data")
    plt.legend()
    plt.title("1D Gaussian GAN")
    plt.show()

    def kl_divergence(p, q):
        epsilon = 1e-10
        p = p + epsilon
        q = q + epsilon
        return np.sum(p * np.log(p / q))
    real = real_samples.flatten()
    fake = fake_samples.flatten()
    bins = 50
    p_real, bin_edges = np.histogram(real, bins=bins, density=True)
    p_fake, _ = np.histogram(fake, bins=bin_edges, density=True)
    p_real = p_real / np.sum(p_real)
    p_fake = p_fake / np.sum(p_fake)
    kl_value = kl_divergence(p_real, p_fake)
    print("KL Divergence (Real || Fake):", kl_value)

    # If KL values are:
    # 0.0-0.1 = excellent (almost identical)
    # 0.1-0.3 = Good
    # 0.3-0.8 = Okay (common)
    # >1.0 = Bad match

if __name__ == "__main__":
    main()