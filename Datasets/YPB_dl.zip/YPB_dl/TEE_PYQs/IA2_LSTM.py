import torch
import torch.nn.functional as F
from torch import nn
import torch.optim as optim
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader, Dataset

device = 'cuda' if torch.cuda.is_available() else 'cpu'

class DNA_Sequence_Dataset(Dataset):
    def __init__(self, sequences, labels):
        super(DNA_Sequence_Dataset, self).__init__()
        self.sequences = sequences
        self.labels = labels
        self.mapping = {'A': 0, 'T': 1, 'G': 2, 'C': 3}

    def __len__(self):
        return len(self.sequences)   # No. of samples

    def __getitem__(self, index):
        seq = self.sequences[index]    # Fetch seq.
        label = self.labels[index]     # Fetch label
        # Convert A,T,G,C → 0,1,2,3
        mapped = torch.tensor([self.mapping[w] for w in seq.strip().upper()], dtype=torch.long)
        # Convert numeric values → one-hot vectors of size 4
        encoded = F.one_hot(mapped, num_classes=4).float()
        return encoded, label

class LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_dim=2):
        super(LSTM, self).__init__()
        self.LSTM = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_dim)

    def forward(self, x):
        _, (h_n, c_n) = self.LSTM(x)    # h_n = hidden state of last time step from all layers
        h_last = h_n[-1]    # Take only last layer hidden state
        out = self.fc(h_last)   # Pass through final layer to get class scores
        return out

def train(train_loader, model, criterion, optimizer):
    model.train()
    total_loss = 0.0
    for data, target in train_loader:
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * data.size(0)
    avg_loss = total_loss / len(train_loader.dataset)
    return avg_loss

def test(test_loader, model):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            _, predicted = torch.max(output, dim=1)
            correct += (predicted == target).sum().item()
            total += target.size(0)
    accuracy = correct / total
    return accuracy

def pad_collate_fn(batch):
    sequences, labels = zip(*batch)
    # Pad variable-length sequences so they all match inside a batch
    padded_sequences = pad_sequence(sequences, batch_first=True, padding_value=0)
    labels = torch.tensor(labels, dtype=torch.long)
    return padded_sequences, labels

# Generate dataset
base_sequences = ["ACGTAGCTAGCT", "GCTAGCTTAGGCA", "CGTACGTAGCTA", "TGCATGCATGCA"]
base_labels = [0, 1, 0, 1]
data, targets = [], []
for i in range(100):
    for label, seq in zip(base_labels, base_sequences):
        data.append(seq)
        targets.append(label)

dataset = DNA_Sequence_Dataset(data, targets)
print(f"Length of the dataset generated: {len(dataset)}")

# Split train/test
train_len = int(len(dataset) * 0.8)
test_len = len(dataset) - train_len
train_dataset, test_dataset = torch.utils.data.random_split(dataset, [train_len, test_len])

train_loader = DataLoader(dataset=train_dataset, batch_size=4, collate_fn=pad_collate_fn)
test_loader = DataLoader(dataset=test_dataset, batch_size=4, collate_fn=pad_collate_fn)

# Model parameters
vocab_size = 4
embed_dim = 4
hidden_dim = 64
output_dim = 2

model = LSTM(input_size=embed_dim, hidden_size=hidden_dim, num_layers=4, output_dim=output_dim).to(device)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Training loop
for epoch in range(50):
    train_loss = train(train_loader, model, criterion, optimizer)
    if (epoch + 1) % 10 == 0:
        print(f"Epoch {epoch+1}: Training Loss = {train_loss:.4f}")

# Final test accuracy
test_acc = test(test_loader, model)
print(f"\nFinal Test Accuracy: {test_acc:.3f}")
