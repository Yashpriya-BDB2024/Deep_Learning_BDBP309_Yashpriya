
# Create an autoencoder class with Linear-ReLU-Linear-ReLU for both encoder and decoder.
# Use this class to generate a latent representation for an input X. X is a 784 dimensional vector.
# Hidden dimension size is 128 and the latent dimension size is 32. You just need to implement a forward pass training and no need to train the network.
# Generate a single input sample of size 784-dim vector at random and generate the latent representation for this input vector.

import torch
import torch.nn as nn
from torch import optim

class Autoencoder(nn.Module):
    def __init__(self):
        super(Autoencoder, self).__init__()

        # Encoder
        self.encoder = nn.Sequential(
            nn.Linear(784, 128),
            nn.ReLU(),
            nn.Linear(128, 32),   # Input (X) to latent variable (z)
            nn.ReLU()
        )

        # Decoder
        self.decoder = nn.Sequential(
            nn.Linear(32, 128),
            nn.ReLU(),
            nn.Linear(128, 784),   # z back to X
            nn.ReLU()
        )

    def forward(self, x):
        latent = self.encoder(x)
        reconstructed = self.decoder(latent)
        return latent, reconstructed

# In case, training the network is asked.
def train_autoencoder(model, data, epochs=10, lr=0.001):
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    for epoch in range(epochs):
        _, reconstructed = model(data)
        loss = criterion(reconstructed, data)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        print(f"Epoch {epoch + 1}, Loss: {loss.item():.6f}")

def main():
    # Generate 784-dim random input
    X = torch.randn(1, 784)
    model = Autoencoder()
    latent_rep, reconstructed = model(X)
    print("Latent representation shape:", latent_rep.shape)
    print(latent_rep)
    train_autoencoder(model, X, epochs=10, lr=0.001)


if __name__ == "__main__":
    main()
