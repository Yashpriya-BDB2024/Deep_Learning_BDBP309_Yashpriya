
###### QUESTION-A2 (Part-1)

# Implement a CNN model (using PyTorch) for image classification using the TinyImageNet dataset. Your train and test set images are in the corresponding folders.
# Use the folder names as class labels. You are free to construct a deep CNN of your choice to maximize performance.
# However, it is essential that: There are at least three convolutional layers in your model.
# Print the training loss and training accuracy periodically after a certain number of epochs.
# Use the trained model to compute the test accuracy across the test set. Print the test accuracy.

import torch.nn.functional as F
from torch import optim
import torch
import torchvision
import torchvision.transforms as transforms
from torch import nn
from torch.utils.data import DataLoader

# Data loading and transform -
transform = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

path_train = "/home/ibab/245HSBD006_DL_Lab_IA1/imagenet_subset/train"
path_test = "/home/ibab/245HSBD006_DL_Lab_IA1/imagenet_subset/test"

train_set = torchvision.datasets.ImageFolder(path_train, transform=transform)
test_set = torchvision.datasets.ImageFolder(path_test, transform=transform)

train_loader = DataLoader(train_set, batch_size=64, shuffle=True)
test_loader = DataLoader(test_set, batch_size=64, shuffle=True)

# CNN Model -
class BasicCNN(nn.Module):
    def __init__(self):
        super(BasicCNN, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

        # After 3 maxpools on 224x224 → 112 → 56 → 28
        flattened_size = 128 * 28 * 28

        self.fc1 = nn.Linear(flattened_size, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))     # [32,112,112]
        x = self.pool(F.relu(self.conv2(x)))     # [64,56,56]
        x = self.pool(F.relu(self.conv3(x)))     # [128,28,28]
        x = x.view(x.size(0), -1)   # flatten
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# Setup
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = BasicCNN().to(device)
optimizer = optim.Adam(model.parameters(), lr=0.001)
criterion = nn.CrossEntropyLoss()

# Training loop
for epoch in range(10):
    model.train()
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        if batch_idx % 100 == 0:
            print(f"Epoch {epoch}, Batch {batch_idx}, Train Loss {loss.item():.4f}")

    # Evaluation
    model.eval()
    correct = 0
    total_loss = 0
    total_samples = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss = criterion(output, target)
            total_loss += test_loss.item() * data.size(0)
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()
            total_samples += data.size(0)

    avg_test_loss = total_loss / total_samples
    accuracy = 100. * correct / total_samples
    print(f"Epoch {epoch} | Test Loss: {avg_test_loss:.4f} | Accuracy: {accuracy:.2f}%")


###### QUESTION-A2 (Part-2)

# Use a pre-trained ResNet-18 model and build a classifier for the TinyImageNet dataset. Use the same dataset as used in question (i).
# Print the model performance (test accuracy) using this approach.

import torch
import torchvision
import torchvision.transforms as transforms
from sklearn.metrics import accuracy_score, classification_report
from sklearn.svm import SVC
import numpy as np
from torch import nn, classes
from torch.utils.data import DataLoader
from torchvision.models import resnet18, ResNet18_Weights

# Select the device -
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

# Data loading and transform -
transform = transforms.Compose([transforms.Resize((224, 224)), transforms.ToTensor(), transforms.Normalize((0.5, 0.5, 0.5),(0.5, 0.5, 0.5))])

path_train="/home/ibab/245HSBD006_DL_Lab_IA1/imagenet_subset/train"
path_test="/home/ibab/245HSBD006_DL_Lab_IA1/imagenet_subset/test"
train_set = torchvision.datasets.ImageFolder(path_train, transform=transform)
test_set = torchvision.datasets.ImageFolder(path_test, transform=transform)
train_loader = DataLoader(train_set, batch_size=64, shuffle=True)
test_loader = DataLoader(test_set, batch_size=64, shuffle=True)

classes = test_set.classes
# X, y = next(iter(train_loader))
# print(X.shape)     # torch.Size([64, 3, 224, 224])
# print(y.shape)     # torch.Size([64])

class FeatureExtractor(nn.Module):
    def __init__(self, backbone):
        super().__init__()
        self.features = nn.Sequential(*list(backbone.children())[:-1])    # remove last FC layer
    def forward(self, x):
        x = self.features(x)
        return x.view(x.size(0), -1)   # flatten

# Load pretrained ResNet18
resnet = resnet18(weights=ResNet18_Weights.DEFAULT)
resnet.eval()
for param in resnet.parameters():
    param.requires_grad = False
feature_extractor = FeatureExtractor(resnet).to(device)

def extract_features(dataloader):
    feats, labels = [], []
    with torch.no_grad():
        for images, lbls in dataloader:
            images = images.to(device)
            outputs = feature_extractor(images)
            feats.append(outputs.cpu().numpy())
            labels.append(lbls.numpy())
    feats = np.concatenate(feats, axis=0)
    labels = np.concatenate(labels, axis=0)
    return feats, labels

print("Extracting training features...")
X_train, y_train = extract_features(train_loader)
print("Extracting test features...")
X_test, y_test = extract_features(test_loader)
print("Train features:", X_train.shape, " Test features:", X_test.shape)

# Train the support vector classifier -
print("Training SVM classifier...")
svc = SVC(kernel='rbf', C=10, gamma='scale')
svc.fit(X_train, y_train)

# Evaluate the classification model -
y_pred = svc.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f"\nTest Accuracy: {acc:.4f}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=classes))

