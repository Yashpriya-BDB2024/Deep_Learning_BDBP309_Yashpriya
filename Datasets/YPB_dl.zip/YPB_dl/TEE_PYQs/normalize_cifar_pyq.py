
### Load the CIFAR-10 dataset & normalize the pixel values to the range [0,1]. You are allowed to use PyTorch library functions.

import torch
import torchvision
import torchvision.transforms as transforms

def load_cifar10():
    # ToTensor() converts image from (H, W, C) to (C, H, W)
    # Also, it scales pixel values from [0, 255] to [0, 1] by dividing px by 255.
    transform = transforms.Compose([transforms.ToTensor()])

    train_set = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
    test_set = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)

    train_loader = torch.utils.data.DataLoader(train_set, batch_size=64, shuffle=True)
    test_loader = torch.utils.data.DataLoader(test_set, batch_size=64, shuffle=False)

    return train_loader, test_loader

train_loader, test_loader = load_cifar10()
# Take one batch
images, labels = next(iter(train_loader))
print("Batch of images shape:", images.shape)   # (64, 3, 32, 32)
print("Batch of labels shape:", labels.shape)   # (64,)
print("Min pixel value:", images.min().item())  # Expect 0.0
print("Max pixel value:", images.max().item())  # Expect 1.0
print("First 5 labels:", labels[:5])


### If question requires to normalize the data as per the mean & std of dataset using transforms.Normalize

# Load CIFAR10 as tensors (without normalization)
transform = transforms.ToTensor()
dataset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)

# Stack all images into a single tensor
loader = torch.utils.data.DataLoader(dataset, batch_size=len(dataset), shuffle=False)
images, _ = next(iter(loader))   # all training images in one batch

# images shape = (50000, 3, 32, 32)
mean = images.mean(dim=[0,2,3])   # mean over N, H, W
std = images.std(dim=[0,2,3])     # std over N, H, W
print("Mean:", mean)
print("Std:", std)

transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize(mean, std)])

# Load dataset with normalization
train_set = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
test_set = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)
train_loader = torch.utils.data.DataLoader(train_set, batch_size=64, shuffle=True)
test_loader = torch.utils.data.DataLoader(test_set, batch_size=64, shuffle=False)
