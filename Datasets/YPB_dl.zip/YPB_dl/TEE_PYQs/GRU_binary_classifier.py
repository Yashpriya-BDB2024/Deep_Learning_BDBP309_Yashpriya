
# 6 sequences (given)
# 6 labels (1,1,0,1,0,1)
# Repeated 100 times → 600 sequences
# GRU classifier
# 80/20 split
# Train 50 epochs
# Show loss every 10 epochs
# Report final accuracy

import torch
import torch.nn.functional as F
from torch import nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence

device = "cuda" if torch.cuda.is_available() else "cpu"

class DNADataset(Dataset):
    def __init__(self, sequences, labels):
        self.sequences = sequences
        self.labels = labels
        self.map = {'A':0,'T':1,'G':2,'C':3}

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        seq = self.sequences[idx]
        mapped = torch.tensor([self.map[b] for b in seq], dtype=torch.long)
        encoded = F.one_hot(mapped, num_classes=4).float()
        return encoded, self.labels[idx]

def pad_collate(batch):
    seqs, labs = zip(*batch)
    padded = pad_sequence(seqs, batch_first=True, padding_value=0)
    labs = torch.tensor(labs, dtype=torch.long)
    return padded, labs

class GRUClassifier(nn.Module):
    def __init__(self, input_dim=4, hidden_dim=64, num_layers=2, output_dim=2):
        super().__init__()
        self.gru = nn.GRU(input_dim, hidden_dim, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)
    def forward(self, x):
        _, h = self.gru(x)
        h_last = h[-1]
        return self.fc(h_last)

def train_loop(loader, model, criterion, optimizer):
    model.train()
    total = 0
    for seq, lab in loader:
        seq, lab = seq.to(device), lab.to(device)
        optimizer.zero_grad()
        out = model(seq)
        loss = criterion(out, lab)
        loss.backward()
        optimizer.step()
        total += loss.item() * seq.size(0)
    return total / len(loader.dataset)

def test_loop(loader, model):
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for seq, lab in loader:
            seq, lab = seq.to(device), lab.to(device)
            out = model(seq)
            _, pred = torch.max(out, 1)
            correct += (pred == lab).sum().item()
            total += lab.size(0)
    return correct / total

# PART (a) — Generate 600 sequences
base_sequences = [
    "CAGTAGCTAGCT", "CGTAGCTGAGCA", "CGTAGCTAGCTA",
    "TGCATGCATGCA", "GCTAGCTGAGCA", "GCTAGCTAGCTA"
]
base_labels = [1, 1, 0, 1, 0, 1]     # as given (y)
data, labels = [], []
for _ in range(100):                  # 100 × 6 = 600 sequences
    for seq, lab in zip(base_sequences, base_labels):
        data.append(seq)
        labels.append(lab)
dataset = DNADataset(data, labels)

# PART (b) — Train GRU for 50 epochs
train_size = int(0.8 * len(dataset))
test_size = len(dataset) - train_size
train_ds, test_ds = torch.utils.data.random_split(dataset, [train_size, test_size])
train_loader = DataLoader(train_ds, batch_size=4, collate_fn=pad_collate)
test_loader  = DataLoader(test_ds, batch_size=4, collate_fn=pad_collate)

model = GRUClassifier().to(device)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

for epoch in range(50):
    loss = train_loop(train_loader, model, criterion, optimizer)
    if (epoch + 1) % 10 == 0:
        print(f"Epoch {epoch+1}: Loss = {loss:.4f}")

acc = test_loop(test_loader, model)
print(f"\nFinal Test Accuracy: {acc:.3f}")
