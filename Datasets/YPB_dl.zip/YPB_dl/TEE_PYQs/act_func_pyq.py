# Implement the following functions in Python from scratch. Do not use any library functions. You are allowed to use matplotlib.
# Generate 100 equally spaced values between -10 and 10. Call this list as z. Implement the following functions and their derivative.
# Use z as input and plot both the function outputs and its derivative outputs:
# i. Sigmoid
# ii. Tanh
# iii. ReLU (Rectified Linear Unit)

import matplotlib.pyplot as plt

# Function to generate equally spaced values
def generate_values(start, end, num_points):
    step = (end - start) / (num_points - 1)
    values = []
    current = start
    for _ in range(num_points):
        values.append(current)
        current += step
    return values

# Sigmoid (g(z) = 1/(1+e^-z)) and derivative (g(z)*(1-g(z)))
def sigmoid(x):
    return 1 / (1 + (2.71828 ** (-x)))

def sigmoid_derivative(x):
    s = sigmoid(x)
    return s * (1 - s)

# Tanh ((e^z - e^-z)/(e^z + e^-z)) and derivative (1-tanh(z)^2)
def tanh(x):
    e_pos = 2.71828 ** x
    e_neg = 2.71828 ** (-x)
    return (e_pos - e_neg) / (e_pos + e_neg)

def tanh_derivative(x):
    t = tanh(x)
    return 1 - t * t

# ReLU (max(0,z)) and derivative
def relu(x):
    if x > 0:
        return x
    return 0

def relu_derivative(x):
    if x > 0:
        return 1
    return 0

# Plot function
def plot_functions(z, func, func_derivative, name):
    outputs = [func(val) for val in z]    # applies the function to every value in z
    derivatives = [func_derivative(val) for val in z]

    plt.figure()
    plt.plot(z, outputs, label=f"{name}")
    plt.plot(z, derivatives, label=f"{name} derivative")
    plt.legend()
    plt.title(name)
    plt.show()

# Main execution
z = generate_values(-10, 10, 100)

plot_functions(z, sigmoid, sigmoid_derivative, "Sigmoid")
plot_functions(z, tanh, tanh_derivative, "Tanh")
plot_functions(z, relu, relu_derivative, "ReLU")
