import torchvision
import torch
import numpy as np
from matplotlib import pyplot as plt
from torch import nn

latent_dim=32
batch_size = 64
epochs = 10
learning_rate = 0.001
manual_seed=42
torch.manual_seed(manual_seed)
np.random.seed(manual_seed)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def noisy_data(x,noisy_factor=0.3):
    x_noisy=x+noisy_factor*torch.randn_like(x)
    return torch.clip(x_noisy, 0.0, 1.0)

class DenoisingAutoencoder(nn.Module):
    def __init__(self, latent_dim):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Flatten(),
            nn.Linear(28*28, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, latent_dim),
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, 28*28),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = self.encoder(x)
        x = self.decoder(x)
        x=x.view(-1,1,28,28)
        return x

def main():
    train_data=torchvision.datasets.MNIST(root='./data', train=True, transform=torchvision.transforms.ToTensor(), download=False)
    test_data=torchvision.datasets.MNIST(root='./data', train=False, transform=torchvision.transforms.ToTensor(),download=False)
    train_loader = torch.utils.data.DataLoader(train_data, batch_size=batch_size, shuffle=True)
    test_loader = torch.utils.data.DataLoader(test_data, batch_size=batch_size, shuffle=False)
    data,labels = next(iter(train_loader))
    print(data.shape)
    print(labels.shape)

    # dataset shape - 64, 1, 28, 28
    # auto encoders architecture
    # linear(28*28->256) - relu - linear(256->latent dim) - latent dim - linear(latent dim-> 256) - relu - linear(256->28*28) - sigmoid

    model = DenoisingAutoencoder(latent_dim).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    loss_fn = nn.MSELoss()

    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for data, _ in train_loader:
            data=data.to(device)
            data_noisy=noisy_data(data)
            optimizer.zero_grad()
            output = model(data_noisy)
            loss = loss_fn(output, data)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()*data.size(0)

        total_loss = total_loss/len(train_loader.dataset)
        if epoch % 2 == 0:
            print(f'[TRAINING] epoch {epoch}, loss {total_loss:.3f}')

    model.eval()
    total_loss = 0
    with torch.no_grad():
        for data, _ in test_loader:
            data=data.to(device)
            data_noisy=noisy_data(data)
            output = model(data_noisy)
            loss = loss_fn(output, data)
            total_loss += loss.item()*data.size(0)
    total_loss = total_loss/len(test_loader.dataset)
    print(f'[TESTING] loss {total_loss:.3f}')

    # visualisation
    test_images,test_labels = next(iter(test_loader))
    test_images=test_images.to(device)
    test_noisy=noisy_data(test_images)
    reconstructions = model(test_noisy).detach().numpy()

    plt.figure(figsize=(10,10))
    for i in range(6):
        plt.subplot(3,6,i+1)
        plt.imshow(test_images[i].squeeze(), cmap='gray')
        plt.axis('off')

        plt.subplot(3,6,6+i+1)
        plt.imshow(test_noisy[i].squeeze(), cmap='gray')
        plt.axis('off')

        plt.subplot(3,6,6+6+i+1)
        plt.imshow(reconstructions[i].squeeze(), cmap='gray')
        plt.axis('off')
    plt.show()

if __name__ == '__main__':
    main()

# Latent Dim = 32
# Smallest bottleneck
# Autoencoder must compress too much
# Loses fine details
# Reconstructions look blurry, edges less sharp
# Good for strong dimensionality reduction, but worse quality

# Latent Dim = 64
# Good trade-off
# Preserves most digit structure
# Reconstructions are clear and recognizable
# Rarely loses shape
# Recommended default

# Latent Dim = 128
# Large bottleneck → model memorizes more detail
# Reconstructions look very sharp, almost identical to input
# Risk of overfitting
# More computation
