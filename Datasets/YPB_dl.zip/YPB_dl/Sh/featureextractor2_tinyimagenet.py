from random import random
import numpy as np
import torch
import torchvision
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from torch import nn
from torch.utils.data import DataLoader
from torchvision import transforms, models
from torchvision.datasets import ImageFolder

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
torch.manual_seed(42)
np.random.seed(42)

batch_size = 32
num_classes = 5

def FeatureExtractor(model,loader):
    model.eval()
    data=[]
    labels=[]
    for image,label in loader:
        image,label = image.to(device),label.to(device)
        feature = model(image)
        feature = feature.view(feature.shape[0],-1).cpu().numpy()
        data.append(feature)
        labels.append(label.cpu().numpy())
    return np.concatenate(data,axis=0),np.concatenate(labels,axis=0)

def main():
    # Load pretrained ResNet18
    model = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)

    # Freeze all layers
    for param in model.parameters():
        param.requires_grad = False

    model=nn.Sequential(*list(model.children())[:-1])
    model = model.to(device)

    # Dataset + DataLoader
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ])

    train_dataset = ImageFolder('./data/imagenet_subset/train', transform=transform)
    test_dataset = ImageFolder('./data/imagenet_subset/test', transform=transform)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    X_train, y_train = FeatureExtractor(model,train_loader)
    X_test, y_test = FeatureExtractor(model,test_loader)

    scaler=StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    model_classifier = SVC(kernel='rbf', C=10, gamma='scale')
    model_classifier.fit(X_train_scaled,y_train)
    y_pred=model_classifier.predict(X_test_scaled)

    print(classification_report(y_test,y_pred))
    print(confusion_matrix(y_test,y_pred))

if __name__ == "__main__":
    main()
