# Corrected GAN to learn y = sin(x) without dashed comments
import math
import numpy as np
import torch
from torch import nn, optim
from torch.utils.data import DataLoader, TensorDataset
import matplotlib.pyplot as plt

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.manual_seed(42)
np.random.seed(42)

latent_dim = 10
hidden_dim = 128
output_dim = 2
train_data_length = 1024
batch_size = 64
lr = 2e-4
epochs = 2000
print_every = 100

# Create sine wave training data
x = 2 * math.pi * torch.rand(train_data_length, 1)
y = torch.sin(x)
real_data = torch.cat([x, y], dim=1)
dataset = TensorDataset(real_data)
loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=True)

# Generator (no dropout / no BN)
class Generator(nn.Module):
    def __init__(self, latent_dim, hidden_dim, output_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(True),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(True),
            nn.Linear(hidden_dim, output_dim)
        )
    def forward(self, z):
        return self.net(z)

# Discriminator (no BN, returns logits)
class Discriminator(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Linear(hidden_dim, 1)
        )
    def forward(self, x):
        return self.net(x)

G = Generator(latent_dim, hidden_dim, output_dim).to(device)
D = Discriminator(output_dim, hidden_dim).to(device)

criterion = nn.BCEWithLogitsLoss()
opt_G = optim.Adam(G.parameters(), lr=lr, betas=(0.5, 0.999))
opt_D = optim.Adam(D.parameters(), lr=lr, betas=(0.5, 0.999))

# Training loop
for epoch in range(1, epochs + 1):
    epoch_loss_D = 0.0
    epoch_loss_G = 0.0

    for (real_batch,) in loader:
        real_batch = real_batch.to(device)
        b_size = real_batch.size(0)

        real_labels = torch.ones((b_size, 1), device=device)
        fake_labels = torch.zeros((b_size, 1), device=device)

        # Train discriminator
        logits_real = D(real_batch)
        loss_real = criterion(logits_real, real_labels)

        z = torch.randn(b_size, latent_dim, device=device)
        fake_batch = G(z).detach()
        logits_fake = D(fake_batch)
        loss_fake = criterion(logits_fake, fake_labels)

        loss_D = (loss_real + loss_fake) * 0.5

        opt_D.zero_grad()
        loss_D.backward()
        opt_D.step()

        # Train generator
        z2 = torch.randn(b_size, latent_dim, device=device)
        fake_for_g = G(z2)
        logits_fake_for_g = D(fake_for_g)
        loss_G = criterion(logits_fake_for_g, real_labels)

        opt_G.zero_grad()
        loss_G.backward()
        opt_G.step()

        epoch_loss_D += loss_D.item()
        epoch_loss_G += loss_G.item()

    epoch_loss_D /= len(loader)
    epoch_loss_G /= len(loader)

    if epoch % print_every == 0 or epoch == 1:
        print(f"Epoch {epoch}/{epochs}  Loss_D: {epoch_loss_D:.4f}  Loss_G: {epoch_loss_G:.4f}")

# Generate samples after training
G.eval()
with torch.no_grad():
    z = torch.randn(1024, latent_dim, device=device)
    fake = G(z).cpu().numpy()
real_full = real_data.numpy()

plt.figure(figsize=(8,5))
plt.scatter(real_full[:,0], real_full[:,1], s=8, alpha=0.5, label="Real")
plt.scatter(fake[:,0], fake[:,1], s=8, alpha=0.6, label="Generated")
plt.legend()
plt.title("Sine curve: Real vs Generated")
plt.xlabel("x")
plt.ylabel("y")
plt.show()
