import numpy as np
import torch
from sklearn.model_selection import train_test_split
from torch import nn
from torch.nn.utils.rnn import pad_sequence, pack_padded_sequence
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm

# Hyperparameters
EPOCHS = 50
VOCAB_SIZE = 4
EMBED_DIM = 10
HIDDEN_DIM = 15
NUM_LAYERS = 3
OUTPUT_CLASSES = 2
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Set manual seeds
manual_seed = 42
torch.manual_seed(manual_seed)
np.random.seed(manual_seed)

# Dataset
class DNA_dataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels
        self.mapping = {'A': 0, 'C': 1, 'G': 2, 'T': 3}

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        seq = self.data[idx]
        label = self.labels[idx]
        mapped = [self.mapping[ch] for ch in seq.strip().upper()]
        return torch.tensor(mapped, dtype=torch.long), torch.tensor(label, dtype=torch.long)

# GRU Classifier + Packed sequence handling
class DNA_classifier(nn.Module):
    def __init__(self, VOCAB_SIZE, EMBED_DIM, HIDDEN_DIM, NUM_LAYERS):
        super().__init__()

        self.embedding = nn.Embedding(VOCAB_SIZE, EMBED_DIM)

        self.lstm = nn.LSTM(
            EMBED_DIM,
            HIDDEN_DIM,
            NUM_LAYERS,
            batch_first=True  # IMPORTANT
        )

        self.fc = nn.Sequential(
            nn.Linear(HIDDEN_DIM, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Dropout(0.3),

            nn.Linear(64, 32),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.Dropout(0.3),

            nn.Linear(32, OUTPUT_CLASSES)
        )

    def forward(self, x, lengths):
        x = self.embedding(x)     # (B, L, EMBED)

        # pack padded batch
        packed = pack_padded_sequence(
            x, lengths.cpu(),  # lengths must be CPU
            batch_first=True,
            enforce_sorted=False
        )

        _, (h,c) = self.lstm(packed)
        h_last = h[-1]  # last layer

        out = self.fc(h_last)
        return out

# Collate function (returns padded batch + lengths)
def pad_collate_fn(batch):
    sequences, labels = zip(*batch)
    lengths = torch.tensor([len(seq) for seq in sequences], dtype=torch.long)

    padded_sequences = pad_sequence(
        sequences, batch_first=True, padding_value=0
    )

    labels = torch.tensor(labels, dtype=torch.long)

    return padded_sequences, labels, lengths

# Training Loop
def train(model, train_loader, optimizer, criterion):
    model.train()
    total_loss = 0
    correct = 0
    total = 0

    for data, target, lengths in tqdm(train_loader):
        data, target, lengths = data.to(DEVICE), target.to(DEVICE), lengths.to(DEVICE)

        optimizer.zero_grad()
        output = model(data, lengths)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * data.size(0)
        _, pred = torch.max(output, 1)
        correct += (pred == target).sum().item()
        total += target.size(0)

    return total_loss / len(train_loader.dataset), correct / total

# Test Loop
def test(model, test_loader, criterion):
    model.eval()
    total_loss = 0
    correct = 0
    total = 0

    with torch.no_grad():
        for data, target, lengths in tqdm(test_loader):
            data, target, lengths = data.to(DEVICE), target.to(DEVICE), lengths.to(DEVICE)
            output = model(data, lengths)
            loss = criterion(output, target)

            total_loss += loss.item() * data.size(0)
            _, pred = torch.max(output, 1)
            correct += (pred == target).sum().item()
            total += target.size(0)

    return total_loss / len(test_loader.dataset), correct / total

def main():
    # Data Preparation
    base_sequences = [
        "CATGCATGACTT", "CGTAGCTGAGCA",
        "GCATGCAGCTTA", "TGCATGCATGCA",
        "GCTACGTAGGCA", "GTACGTAGCTA"
    ]
    base_labels = [1, 1, 0, 1, 0, 1]

    data = base_sequences * 100
    labels = base_labels * 100

    X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2)

    train_ds = DNA_dataset(X_train, y_train)
    test_ds = DNA_dataset(X_test, y_test)

    train_loader = DataLoader(train_ds, batch_size=64, shuffle=True,
                              num_workers=4, collate_fn=pad_collate_fn)
    test_loader = DataLoader(test_ds, batch_size=64, shuffle=False,
                             num_workers=4, collate_fn=pad_collate_fn)

    # Model, Loss, Optimizer
    model = DNA_classifier(VOCAB_SIZE, EMBED_DIM, HIDDEN_DIM, NUM_LAYERS).to(DEVICE)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)

    # Training
    for epoch in range(1, EPOCHS + 1):
        train_loss, train_acc = train(model, train_loader, optimizer, criterion)
        scheduler.step()

        if epoch % 10 == 0:
            print(f"[TRAINING] Epoch {epoch} | Loss: {train_loss:.4f} | Acc: {train_acc:.4f}")

    # Testing
    test_loss, test_acc = test(model, test_loader, criterion)
    print(f"\n[TESTING] Loss: {test_loss:.4f} | Acc: {test_acc:.4f}")

if __name__ == "__main__":
    main()