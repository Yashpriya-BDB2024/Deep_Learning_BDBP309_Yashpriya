import torch
from torch import nn


# class simpleNN(nn.Module):
#     def __init__(self,inputSize,outputSize,hidden=[],activation=None):
#         super(simpleNN, self).__init__()
#         activation_dict = {'relu':nn.ReLU(),'sigmoid':nn.Sigmoid(),'tanh':nn.Tanh()}
#         layers = []
#         in_size = inputSize
#         for h in hidden:
#             layers.append(nn.Linear(in_size,h))
#             if activation is not None:
#                 layers.append(activation_dict[activation])
#             in_size = h
#         layers.append(nn.Linear(in_size,outputSize))
#         self.network = nn.Sequential(*layers)
#     def forward(self,x):
#         return self.network(x)
# x=torch.randn(1,3)
# y=torch.randn(1)
# model=simpleNN(x.shape[1],y.shape[0])
# print(model(x))

class simpleNN(nn.Module):
    def __init__(self, inputSize, outputSize, activation=None):
        super().__init__()
        self.linear = nn.Linear(inputSize, outputSize)

        activation_dict = {
            'relu': nn.ReLU(),
            'sigmoid': nn.Sigmoid(),
            'tanh': nn.Tanh()
        }

        # Default activation = identity (no activation)
        self.activation = activation_dict.get(activation, nn.Identity())

    def forward(self, x):
        x = self.linear(x)
        x = self.activation(x)
        return x

x = torch.randn(1, 3)
model = simpleNN(3, 1)
print(model(x))
