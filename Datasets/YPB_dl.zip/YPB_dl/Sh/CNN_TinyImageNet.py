from random import random
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.datasets import ImageFolder

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
manual_seed=42
torch.manual_seed(manual_seed)
np.random.seed(manual_seed)

epochs=5
batch_size=32
learning_rate=0.001
num_classes=5
in_channels=3

class TinyImageNet_classifier(nn.Module):
    def __init__(self,in_channels,num_classes):
        super().__init__()
        self.network = nn.Sequential(
            nn.Conv2d(in_channels=in_channels,out_channels=16,kernel_size=3, stride=2, padding=1), # 3*224*224 -> 16*112*112
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2), # 16*112*112 -> 16*56*56
            nn.Conv2d(in_channels=16,out_channels=32,kernel_size=3, stride=2, padding=1), # 16*56*56 -> 32*28*28
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2), # 32*28*28 -> 32*14*14
            nn.Conv2d(in_channels=32,out_channels=64,kernel_size=3, stride=1, padding=1), # 32*14*14 -> 64*14*14
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2) # 64*14*14 -> 64*7*7
        )
        self.fc=nn.Sequential(
            nn.Linear(in_features=64*7*7,out_features=256),
            nn. BatchNorm1d(num_features=256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(in_features=256,out_features=128),
            nn. BatchNorm1d(num_features=128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(in_features=128,out_features=num_classes)
        )

    def forward(self,x):
        x = self.network(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x

def train(model,train_loader,optimizer,criterion):
    model.train()
    total_loss = 0
    correct = 0
    total = 0
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()*data.size(0)
        _, predicted = output.max(1)
        total += target.size(0)
        correct += predicted.eq(target).sum().item()
    total_loss = total_loss / len(train_loader.dataset)
    acc = correct / total
    return total_loss, acc

def test(model,test_loader,criterion):
    model.eval()
    total_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            loss = criterion(output, target)
            total_loss += loss.item()*data.size(0)
            _, predicted = output.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
    total_loss = total_loss / len(test_loader.dataset)
    acc = correct / total
    return total_loss, acc

def main():
    train_dir='./data/imagenet_subset/train'
    test_dir='./data/imagenet_subset/test'
    transform = transforms.Compose([transforms.Resize(size=(224,224)),
                                    transforms.ToTensor(),
                                    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                    std=[0.229, 0.224, 0.225])])
    train_dataset = ImageFolder(train_dir, transform=transform)
    test_dataset = ImageFolder(test_dir, transform=transform)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    print(train_dataset.classes)
    images,labels = next(iter(test_loader))
    print(images.shape)
    print(labels.shape)

    model = TinyImageNet_classifier(in_channels,num_classes).to(device)
    loss_function = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    for epoch in range(epochs):
        total_train_loss, train_acc = train(model,train_loader,optimizer,loss_function)
        print(f"[TRAINING] Epoch {epoch} Train loss {total_train_loss} Train acc {train_acc}")
    total_test_loss, test_acc = test(model,test_loader,loss_function)
    print(f"[TEST] Test loss {total_test_loss} Test acc {test_acc}")

if __name__ == '__main__':
    main()
