import numpy as np
import torch
import torchvision
from torch import nn
from torchvision import transforms
from tqdm import tqdm

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
manual_seed=42
torch.manual_seed(manual_seed)
np.random.seed(manual_seed)

class Cifar10_classifier(nn.Module):
    def __init__(self,in_features,out_features):
        super().__init__()

        # CONV → CONV → MAXPOOL
        self.network = nn.Sequential(
            nn.Conv2d(in_features, 32, kernel_size=3, stride=1, padding=1),  # 3×32×32 → 32×32×32
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),  # 32×32×32 → 64×32×32
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2, stride=2)  # 64×16×16
        )

        # LINEAR → LINEAR
        self.fc = nn.Sequential(
            nn.Linear(64 * 16 * 16, 128),
            nn.ReLU(),
            nn.Linear(128, out_features)
        )

    def forward(self, x):
        x = self.network(x)
        x = x.view(x.size(0), -1)  # flatten
        x = self.fc(x)
        return x

def train(model, train_loader, criterion, optimizer):
    model.train()
    total_loss = 0
    correct = 0
    total = 0
    for data, target in tqdm(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()*data.size(0)
        _, predicted = torch.max(output, 1)
        total += target.size(0)
        correct+=(predicted==target).sum().item()
    accuracy = correct/total
    total_loss = total_loss/len(train_loader.dataset)
    return total_loss,accuracy

def test(model, test_loader, criterion):
    model.eval()
    total_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for data, target in tqdm(test_loader):
            data, target = data.to(device), target.to(device)
            output = model(data)
            loss = criterion(output, target)
            total_loss += loss.item()*data.size(0)
            _, predicted = torch.max(output, 1)
            total += target.size(0)
            correct+=(predicted==target).sum().item()
    accuracy = correct/total
    total_loss = total_loss/len(test_loader.dataset)
    return total_loss,accuracy

def main():
    transform=transforms.Compose([transforms.ToTensor(),
                                  transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
    dir='data'
    train_dataset=torchvision.datasets.CIFAR10(root=dir, train=True, download=False, transform=transform)
    test_dataset=torchvision.datasets.CIFAR10(root=dir,train=False,download=False,transform=transform)

    train_loader=torch.utils.data.DataLoader(train_dataset,batch_size=64,shuffle=True)
    test_loader=torch.utils.data.DataLoader(test_dataset,batch_size=64,shuffle=False)

    image,label=next(iter(train_loader))
    print(image.shape)
    print(label.shape)

    input_channels=3
    num_classes=10
    model=Cifar10_classifier(input_channels,num_classes).to(device)
    criterion=nn.CrossEntropyLoss()
    optimizer=torch.optim.Adam(model.parameters(),lr=0.001)
    lr_scheduler=torch.optim.lr_scheduler.StepLR(optimizer,step_size=3,gamma=0.1)

    for epoch in range(1,6):
        total_loss,accuracy=train(model,train_loader,criterion,optimizer)
        lr_scheduler.step()
        print(f'[TRAINING] Epoch {epoch} Loss: {total_loss} Accuracy: {accuracy}')

    test_loss,test_accuracy=test(model,test_loader,criterion)
    print(f'[TESTING] Loss: {test_loss} Accuracy: {test_accuracy}')

if __name__=='__main__':
    main()