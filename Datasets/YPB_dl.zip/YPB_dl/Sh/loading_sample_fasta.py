import torch
from torch.nn.functional import one_hot
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import random_split, DataLoader

def parse_fasta(fasta_file):
    with open(fasta_file, 'r') as f:
        seq={}
        for line in f:
            line = line.strip()
            if line.startswith('>'):
                seq_id = line[1:]
            else:
                seq[seq_id] = line.upper()
    print(seq)
    return seq

class DNASequence:
    def __init__(self, fasta_file):
        self.sequence=parse_fasta(fasta_file)
        self.seq_ids=list(self.sequence.keys())
        self.mapper={'A':0,'C':1,'G':2,'T':3}

    def __len__(self):
        return len(self.sequence)

    def __getitem__(self, idx):
        seq_id = self.seq_ids[idx]
        seq_mapped=[self.mapper[n] for n in self.sequence[seq_id].strip()]
        seq_mapped=torch.tensor(seq_mapped,dtype=torch.long)
        seq_one_hot=one_hot(seq_mapped,num_classes=4).float()
        return seq_id,seq_one_hot

def collate_func(batch):
    seq_id,seq_one_hot=zip(*batch)
    seq_padded=pad_sequence(seq_one_hot, batch_first=True, padding_value=0)
    return seq_padded

def main():
    path='./data/sample.fasta'
    data=DNASequence(path)
    train_len=int(len(data)*0.8)
    test_len=len(data)-train_len
    train_data,test_data=random_split(data,[train_len,test_len])
    train_loader=DataLoader(train_data,batch_size=2,shuffle=True,collate_fn=collate_func)
    test_loader=DataLoader(test_data,batch_size=2,shuffle=False,collate_fn=collate_func)
    for seq_id,seq in train_loader:
        print(seq_id)
        print(seq)
        print(seq.shape)
        print(seq[0].shape)
        break


if __name__ == '__main__':
    main()