import numpy as np
from matplotlib import pyplot as plt

def sigmoid(x):
    return 1 / (1 + np.exp(-x))
def derivative_sigmoid(x):
    y=sigmoid(x)
    return y * (1 - y)
def relu(x):
    return np.maximum(0, x)
def derivative_relu(x):
    return np.where(x>0,1,0)
def leaky_relu(x, alpha=0.01):
    return np.maximum(alpha * x, x)
def derivative_leaky_relu(x, alpha=0.01):
    return np.where(x>0,1,alpha)
def tanh(x):
    return np.tanh(x)
def derivative_tanh(x):
    return 1 - np.tanh(x)**2

# def softmax(x):
#     return np.exp(x) / np.sum(np.exp(x), axis=0)

def plot_activations(x,f_x,f_x_x):
    plt.figure(figsize=(10,10))
    plt.plot(x,f_x,'r-',label='f(x)')
    plt.plot(x,f_x_x,'b-',label='f\'(x)')
    plt.legend(loc='best')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.title('Activation Functions')
    plt.tight_layout()
    plt.grid(True)
    plt.show()

def main():
    x=np.linspace(-10,10,100)
    f_x_s=sigmoid(x)
    f_x_x_s=derivative_sigmoid(x)
    f_x_t=tanh(x)
    f_x_x_t=derivative_tanh(x)
    f_x_r=relu(x)
    f_x_x_r=derivative_relu(x)
    f_x_lr=leaky_relu(x)
    f_x_x_lr=derivative_leaky_relu(x)
    print('x: ',x)
    print('Sigmoid(x):')
    print('f(x)=',f_x_s)
    print('f\'(x)=',f_x_x_s)
    print('Tanh(x):')
    print('f(x)=',f_x_t)
    print('f\'(x)=',f_x_x_t)
    print('ReLU(x):')
    print('f(x)=',f_x_r)
    print('f\'(x)=',f_x_x_r)
    print('LeakyRelu(x):')
    print('f(x)=', f_x_lr)
    print('f\'(x)=', f_x_x_lr)

    plot_activations(x,f_x_s,f_x_x_s)
    plot_activations(x,f_x_t,f_x_x_t)
    plot_activations(x,f_x_r,f_x_x_r)
    plot_activations(x,f_x_lr,f_x_x_lr)

if __name__ == '__main__':
    main()
