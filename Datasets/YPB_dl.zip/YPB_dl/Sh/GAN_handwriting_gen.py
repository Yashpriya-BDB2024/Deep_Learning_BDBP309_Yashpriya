import torch
from torch import nn
import matplotlib.pyplot as plt
import torchvision
import torchvision.transforms as transforms

# reproducibility
torch.manual_seed(111)

# device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# MNIST transform
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

# dataset & loader
train_set = torchvision.datasets.MNIST(
    root="./data", train=True, download=True, transform=transform
)

batch_size = 32
train_loader = torch.utils.data.DataLoader(
    train_set, batch_size=batch_size, shuffle=True, drop_last=True
)

# show samples
real_samples, _ = next(iter(train_loader))
for i in range(16):
    plt.subplot(4, 4, i + 1)
    plt.imshow(real_samples[i].reshape(28, 28), cmap="gray")
    plt.xticks([])
    plt.yticks([])
plt.show()

# Discriminator
class Discriminator(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(784, 512),
            nn.LeakyReLU(0.2, inplace=True),

            nn.Linear(512, 256),
            nn.LeakyReLU(0.2, inplace=True),

            nn.Linear(256, 1)
        )

    def forward(self, x):
        x = x.view(x.size(0), 784)
        return self.model(x)

discriminator = Discriminator().to(device)

# Generator
class Generator(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(100, 256),
            nn.ReLU(inplace=True),

            nn.Linear(256, 512),
            nn.ReLU(inplace=True),

            nn.Linear(512, 1024),
            nn.ReLU(inplace=True),

            nn.Linear(1024, 784),
            nn.Tanh()
        )

    def forward(self, x):
        x = self.model(x)
        return x.view(x.size(0), 1, 28, 28)

generator = Generator().to(device)

# training setup
lr = 0.0001
num_epochs = 50

loss_function = nn.BCEWithLogitsLoss()   # stable version
optimizer_D = torch.optim.Adam(discriminator.parameters(), lr=lr)
optimizer_G = torch.optim.Adam(generator.parameters(), lr=lr)

# Training Loop
for epoch in range(num_epochs):
    for batch_idx, (real_imgs, _) in enumerate(train_loader):

        real_imgs = real_imgs.to(device)
        bsize = real_imgs.size(0)

        real_labels = torch.ones((bsize, 1), device=device)
        fake_labels = torch.zeros((bsize, 1), device=device)

        # Train Discriminator
        latent = torch.randn(bsize, 100, device=device)
        fake_imgs = generator(latent)

        pred_real = discriminator(real_imgs)
        loss_real = loss_function(pred_real, real_labels)

        pred_fake = discriminator(fake_imgs.detach())
        loss_fake = loss_function(pred_fake, fake_labels)

        loss_D = loss_real + loss_fake

        optimizer_D.zero_grad()
        loss_D.backward()
        optimizer_D.step()

        # Train Generator
        latent2 = torch.randn(bsize, 100, device=device)
        fake_imgs2 = generator(latent2)
        pred_fake2 = discriminator(fake_imgs2)

        loss_G = loss_function(pred_fake2, real_labels)

        optimizer_G.zero_grad()
        loss_G.backward()
        optimizer_G.step()

    print(f"Epoch {epoch+1}/{num_epochs}  Loss_D: {loss_D.item():.4f}  Loss_G: {loss_G.item():.4f}")

# Generate and display samples
latent_test = torch.randn(16, 100, device=device)
generated = generator(latent_test).cpu().detach()

for i in range(16):
    plt.subplot(4, 4, i + 1)
    plt.imshow(generated[i].reshape(28, 28), cmap="gray")
    plt.xticks([])
    plt.yticks([])
plt.show()
