import torchvision
import torch
from torch import nn
from torchvision import transforms
from tqdm import tqdm

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
class MNIST_Classifier(nn.Module):
    def __init__(self,input_size,hidden_size1,hidden_size2,output_size):
        super().__init__()
        layers=[]
        layers.append(nn.Linear(input_size,hidden_size1))
        layers.append(nn.ReLU())
        layers.append(nn.Linear(hidden_size1,hidden_size2))
        layers.append(nn.ReLU())
        layers.append(nn.Linear(hidden_size2,output_size))
        self.network = nn.Sequential(*layers)
    def forward(self,x):
        x=x.reshape(x.shape[0],-1)
        return self.network(x)

def train(model,train_loader,criterion,optimizer):
    model.train()
    total_loss = 0
    correct = 0
    total = 0
    for data,target in tqdm(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()*data.size(0)
        _,predicted = torch.max(output,1)
        correct+=(predicted==target).sum().item()
        total += target.size(0)
    total_loss /= len(train_loader.dataset)
    accuracy=correct/total
    return total_loss,accuracy

def test(model,test_loader,criterion):
    model.eval()
    total_loss = 0
    correct = 0
    total=0
    with torch.no_grad():
        for data,target in tqdm(test_loader):
            data, target = data.to(device), target.to(device)
            output = model(data)
            loss = criterion(output, target)
            total_loss += loss.item()*data.size(0)
            predicted = torch.max(output,1)[1]
            correct += (predicted==target).sum().item()
            total += target.size(0)
    total_loss /= len(test_loader.dataset)
    accuracy=correct/total
    return total_loss,accuracy

def main():
    transform = transforms.Compose([transforms.ToTensor()])
    train_data=torchvision.datasets.MNIST(root='data',download=False,transform=transform,train=True)
    test_data=torchvision.datasets.MNIST(root='data',download=False,transform=transform,train=False)
    train_loader=torch.utils.data.DataLoader(dataset=train_data,batch_size=64,shuffle=True)
    test_loader=torch.utils.data.DataLoader(dataset=test_data,batch_size=64,shuffle=False)
    data,labels=next(iter(train_loader))
    print(data.shape)
    print(labels.shape)

    input_size=784
    hidden_size1=128
    hidden_size2=64
    output_size=10

    model = MNIST_Classifier(input_size,hidden_size1,hidden_size2,output_size).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer=torch.optim.Adam(model.parameters(),lr=0.001)

    for epoch in range(1,6):
        total_loss,accuracy=train(model,train_loader,criterion,optimizer)
        print(f"[TRAINING] Epoch {epoch}, Training loss {total_loss:.3f}, Training accuracy {accuracy:.3f}")
    total_loss_test,accuracy_test=test(model,test_loader,criterion)
    print(f"[TEST] Test loss {total_loss_test: .3f},Test accuracy {accuracy_test:.3f}")

if __name__ == '__main__':
    main()
