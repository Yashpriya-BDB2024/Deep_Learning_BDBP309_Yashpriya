import torchvision
import torch.nn as nn
import torch
from torchvision import transforms

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
num_classes = 10
learning_rate = 0.001
epochs = 25
batch_size = 64

class FashionMNIST_Classifier(nn.Module):
    def __init__(self,input_size,num_classes,hidden_layers=[]):
        super().__init__()
        layers = []
        in_size = input_size
        layers.append(nn.Flatten())
        for h in hidden_layers:
            layers.append(nn.Linear(in_size, h))
            layers.append(nn.BatchNorm1d(h))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.2))
            in_size = h
        layers.append(nn.Linear(in_size, num_classes))
        self.net = nn.Sequential(*layers)
    def forward(self, x):
        return self.net(x)

def train(model,train_loader,optimizer,criterion):
    model.train()
    total_loss = 0
    correct = 0
    total = 0
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()*data.size(0)
        _, predicted = output.max(1)
        total += target.size(0)
        correct += predicted.eq(target).sum().item()
    total_loss = total_loss / len(train_loader.dataset)
    acc = correct / total
    return total_loss, acc

def test(model,test_loader,criterion):
    model.eval()
    total_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            loss = criterion(output, target)
            total_loss += loss.item()*data.size(0)
            _, predicted = output.max(1)
            total += target.size(0)
            correct += predicted.eq(target).sum().item()
    total_loss = total_loss / len(test_loader.dataset)
    acc = correct / total
    return total_loss, acc

def main():
    transform = transforms.Compose([transforms.ToTensor()])
    train_data = torchvision.datasets.FashionMNIST(root='data', train=True, download=False, transform=transform)
    test_data = torchvision.datasets.FashionMNIST(root='data', train=False, download=False, transform=transform)
    train_loader = torch.utils.data.DataLoader(train_data, batch_size=batch_size, shuffle=True)
    test_loader = torch.utils.data.DataLoader(test_data, batch_size=batch_size, shuffle=False)

    images, labels = next(iter(train_loader))
    print(len(train_data))
    print(len(test_data))
    print(images.shape)
    print(labels.shape)

    model = FashionMNIST_Classifier(input_size=28*28,num_classes=10,hidden_layers=[256,128,64,32]).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    lr_scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=7, gamma=0.1)

    for epoch in range(epochs):
        total_train_loss, train_acc = train(model,train_loader,optimizer,criterion)
        lr_scheduler.step()
        print(f"Epoch {epoch+1}/{epochs} Loss {total_train_loss:.3f} Acc {train_acc*100:.2f}")

    total_test_loss, test_acc = test(model,test_loader,criterion)
    print(f"Loss {total_test_loss:.3f} Acc {test_acc*100:.2f}")


if __name__ == '__main__':
    main()

