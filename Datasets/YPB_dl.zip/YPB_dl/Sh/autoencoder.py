import numpy as np
import torch
from torch import nn

manual_seed = 42
torch.manual_seed(manual_seed)
np.random.seed(manual_seed)

class autoencoder(nn.Module):
    def __init__(self,inp_size,hidden_size,latent_size):
        super().__init__()
        self.encoder=nn.Sequential(
            nn.Linear(inp_size,hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size,latent_size),
            nn.ReLU()
        )
        self.decoder=nn.Sequential(
            nn.Linear(latent_size,hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size,inp_size),
            nn.ReLU()
        )

    def forward(self, x):
        latent = self.encoder(x)
        reconstructed = self.decoder(latent)
        return latent, reconstructed

inp_size=784
hidden_dim=128
latent_dim=32
X=torch.randn(1, inp_size)
print(f"Input: {X}")
model=autoencoder(inp_size,hidden_dim,latent_dim)
latent, reconstructed = model(X)
print(f"Latent: {latent}")
print(f"Reconstructed: {reconstructed}")

