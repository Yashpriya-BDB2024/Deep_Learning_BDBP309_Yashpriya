import os.path
import pickle
import numpy as np
import torch
import torchvision
from torchvision import transforms

dir = 'data'
transform = transforms.Compose([transforms.ToTensor()])
cifar10 = torchvision.datasets.CIFAR10(root=dir, train=True, download=False, transform=transform)

train_loader = torch.utils.data.DataLoader(cifar10, batch_size=64, shuffle=True)
test_loader = torch.utils.data.DataLoader(cifar10, batch_size=64, shuffle=False)

images, labels = next(iter(train_loader))
print(images.shape)
print(labels.shape)
print(images.min(), images.max())

def load_batch(batch_file):
    with open(batch_file, 'rb') as f:
        batch = pickle.load(f, encoding='bytes')
        data, labels = batch[b'data'], batch[b'labels']
        data = data.reshape(-1, 3, 32, 32)
        return data, labels

X_train = []
Y_train = []

for i in range(1,6):
    data, label = load_batch(os.path.join('data/cifar-10-batches-py', f'data_batch_{i}'))
    X_train.append(data)
    Y_train.extend(label)

X_train = np.concatenate(X_train)
y_train = np.array(Y_train)

X_test, Y_test = load_batch(os.path.join('data/cifar-10-batches-py','test_batch'))
y_test = np.array(Y_test)

print("Pixel range:", X_train.min(), "to", X_train.max())

X_train = X_train.astype(np.float32) / 255.0
X_test = X_test.astype(np.float32) / 255.0

print("X_train shape:", X_train.shape)
print("X_test shape:", X_test.shape)
print("Pixel range:", X_train.min(), "to", X_train.max())
