import torchvision
import torch
import numpy as np
from matplotlib import pyplot as plt
from torch import nn

latent_dim = 32
batch_size = 64
epochs = 10
learning_rate = 0.001
manual_seed = 42
torch.manual_seed(manual_seed)
np.random.seed(manual_seed)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def noisy_data(x, noisy_factor=0.3):
    # Adds gaussian noise & clips values back to [0, 1].
    x_noisy = x + noisy_factor * torch.randn_like(x)
    return torch.clip(x_noisy, 0.0, 1.0)

class DenoisingAutoencoder(nn.Module):
    def __init__(self, latent_dim):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=16, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)
        )
        # Fully connected bottleneck layer
        self.linear= nn.Linear(in_features=32*7*7, out_features=latent_dim)
        # Reverse mapping from latent space to feature map.
        self.reverse_linear=nn.Linear(in_features=latent_dim, out_features=32*7*7)
        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(in_channels=32, out_channels=16, kernel_size=2, stride=2),
            nn.ReLU(),
            nn.ConvTranspose2d(in_channels=16, out_channels=1, kernel_size=2, stride=2),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = self.encoder(x)    # x: (batch_size, 1, 28, 28), after 2nd maxpool - O/P: (batch_size, 32, 7, 7)
        x = self.linear(x.view(x.size(0), -1))    # Flatten each feature map - (32 × 7 × 7) = 1568 values
        x = self.reverse_linear(x).view(-1,32,7,7)    # (batch_size, latent_dim) → (batch_size, 32, 7, 7)
        x = self.decoder(x)   # (32,7,7) → (16,14,14), then (16,14,14) → (1,28,28)
        x = x.view(-1, 1, 28, 28)    # ensures the output has the correct MNIST shape
        return x

def main():
    train_data = torchvision.datasets.MNIST(root='./data', train=True, transform=torchvision.transforms.ToTensor(), download=False)
    test_data = torchvision.datasets.MNIST(root='./data', train=False, transform=torchvision.transforms.ToTensor(), download=False)
    train_loader = torch.utils.data.DataLoader(train_data, batch_size=batch_size, shuffle=True)
    test_loader = torch.utils.data.DataLoader(test_data, batch_size=batch_size, shuffle=False)
    data, labels = next(iter(train_loader))
    print(data.shape)
    print(labels.shape)

    # dataset shape - 64, 1, 28, 28
    # auto encoders architecture
    # conv2d(1*28*28->16*28*28) - relu - maxpool2d(16*28*28->16*14*14)
    # conv2d(16*14*14->32*14*14) - relu - maxpool2d(32*14*14->32*7*7)
    # linear (32*7*7 -> latent_dim)
    # linear (latent_dim -> 32*7*7)
    # convTranspose2d(32*7*7->16*14*14) - relu
    # convTranspose2d(16*14*14->32*28*28) - sigmoid

    model = DenoisingAutoencoder(latent_dim).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    loss_fn = nn.MSELoss()

    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for data, _ in train_loader:
            data = data.to(device)
            data_noisy = noisy_data(data)
            optimizer.zero_grad()
            output = model(data_noisy)
            loss = loss_fn(output, data)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * data.size(0)

        total_loss = total_loss / len(train_loader.dataset)
        if epoch % 2 == 0:
            print(f'[TRAINING] epoch {epoch}, loss {total_loss:.3f}')

    model.eval()
    total_loss = 0
    with torch.no_grad():
        for data, _ in test_loader:
            data = data.to(device)
            data_noisy = noisy_data(data)
            output = model(data_noisy)
            loss = loss_fn(output, data)
            total_loss += loss.item() * data.size(0)
    total_loss = total_loss / len(test_loader.dataset)
    print(f'[TESTING] loss {total_loss:.3f}')

    # visualisation
    test_images, test_labels = next(iter(test_loader))
    test_images = test_images.to(device)
    test_noisy = noisy_data(test_images)
    reconstructions = model(test_noisy).detach().numpy()

    plt.figure(figsize=(10, 10))
    for i in range(6):
        plt.subplot(3, 6, i + 1)
        plt.imshow(test_images[i].squeeze(), cmap='gray')
        plt.axis('off')

        plt.subplot(3, 6, 6 + i + 1)
        plt.imshow(test_noisy[i].squeeze(), cmap='gray')
        plt.axis('off')

        plt.subplot(3, 6, 6 + 6 + i + 1)
        plt.imshow(reconstructions[i].squeeze(), cmap='gray')
        plt.axis('off')
    plt.show()


if __name__ == '__main__':
    main()

# Latent Dim = 32
# Smallest bottleneck
# Autoencoder must compress too much
# Loses fine details
# Reconstructions look blurry, edges less sharp
# Good for strong dimensionality reduction, but worse quality

# Latent Dim = 64
# Good trade-off
# Preserves most digit structure
# Reconstructions are clear and recognizable
# Rarely loses shape
# Recommended default

# Latent Dim = 128
# Large bottleneck → model memorizes more detail
# Reconstructions look very sharp, almost identical to input
# Risk of overfitting
# More computation

# Normal conv
# H_out = ⌊ (H_in + 2*padding − kernel_size) / stride ⌋ + 1
# W_out = ⌊ (W_in + 2*padding − kernel_size) / stride ⌋ + 1

# Transpose conv
# Output_size = (Input_size - 1) * stride - 2*padding + kernel_size + output_padding
