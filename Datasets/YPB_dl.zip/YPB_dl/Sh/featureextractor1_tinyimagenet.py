from random import random
import numpy as np
import torch
import torchvision
from torch import nn
from torch.utils.data import DataLoader
from torchvision import transforms, models
from torchvision.datasets import ImageFolder

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
torch.manual_seed(42)
np.random.seed(42)

epochs = 5
batch_size = 32
learning_rate = 0.001
num_classes = 5

def train(model, loader, optimizer, criterion):
    model.train()
    total_loss = 0
    correct = 0

    for data, target in loader:
        data, target = data.to(device), target.to(device)

        optimizer.zero_grad()
        output = model(data)
        loss = criterion(output, target)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * data.size(0)
        _, predicted = output.max(1)
        correct += predicted.eq(target).sum().item()

    return total_loss / len(loader.dataset), correct / len(loader.dataset)

def test(model, loader, criterion):
    model.eval()
    total_loss = 0
    correct = 0

    with torch.no_grad():
        for data, target in loader:
            data, target = data.to(device), target.to(device)

            output = model(data)
            loss = criterion(output, target)

            total_loss += loss.item() * data.size(0)
            _, predicted = output.max(1)
            correct += predicted.eq(target).sum().item()

    return total_loss / len(loader.dataset), correct / len(loader.dataset)

def main():
    # Load pretrained ResNet18
    model = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)

    # Freeze all layers
    for param in model.parameters():
        param.requires_grad = False

    # Replace final FC layer: 512 → num_classes
    model.fc = nn.Linear(model.fc.in_features, num_classes)

    # Only FC is trainable
    for param in model.fc.parameters():
        param.requires_grad = True

    model = model.to(device)

    # Dataset + DataLoader
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225])
    ])

    train_dataset = ImageFolder('./data/imagenet_subset/train', transform=transform)
    test_dataset = ImageFolder('./data/imagenet_subset/test', transform=transform)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.fc.parameters(), lr=learning_rate)

    for epoch in range(epochs):
        train_loss, train_acc = train(model, train_loader, optimizer, criterion)
        print(f"Epoch {epoch+1}/{epochs} - Loss: {train_loss:.4f} - Acc: {train_acc:.4f}")

    test_loss, test_acc = test(model, test_loader, criterion)
    print(f"\nTEST ACCURACY: {test_acc:.4f}")

if __name__ == "__main__":
    main()
