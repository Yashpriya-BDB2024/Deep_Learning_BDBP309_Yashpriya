import numpy as np
import torch
from matplotlib import pyplot as plt
from torch import nn
from scipy.stats import gaussian_kde

latent_dim = 10
hidden_dim = 128
output_dim = 1
num_epochs = 5000
lr = 0.0002
batch_size = 64

class Generator(nn.Module):
    def __init__(self, latent_dim, hidden_dim, output_dim):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)
        )
    def forward(self, x):
        return self.network(x)

class Discriminator(nn.Module):
    def __init__(self, output_dim, hidden_dim):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(output_dim, hidden_dim),
            nn.LeakyReLU(0.2),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU(0.2),
            nn.Linear(hidden_dim, 1)
        )
    def forward(self, x):
        return self.network(x)

def main():
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    real_data = torch.randn(50000, 1)
    train_loader = torch.utils.data.DataLoader(real_data, batch_size=batch_size, shuffle=True, drop_last=True)

    generator = Generator(latent_dim, hidden_dim, output_dim).to(device)
    discriminator = Discriminator(output_dim, hidden_dim).to(device)

    loss_func = nn.BCEWithLogitsLoss()
    optimizer_gen = torch.optim.Adam(generator.parameters(), lr=lr)
    optimizer_dis = torch.optim.Adam(discriminator.parameters(), lr=lr)

    for epoch in range(num_epochs):
        for true_data in train_loader:
            true_data = true_data.to(device)
            bsize = true_data.size(0)

            real_labels = torch.ones((bsize, 1), device=device)
            fake_labels = torch.zeros((bsize, 1), device=device)

            z = torch.randn(bsize, latent_dim, device=device)
            fake_data = generator(z)

            pred_real = discriminator(true_data)
            pred_fake = discriminator(fake_data.detach())

            loss_D = loss_func(pred_real, real_labels) + loss_func(pred_fake, fake_labels)

            optimizer_dis.zero_grad()
            loss_D.backward()
            optimizer_dis.step()

            z2 = torch.randn(bsize, latent_dim, device=device)
            fake_data2 = generator(z2)
            pred_fake2 = discriminator(fake_data2)

            loss_G = loss_func(pred_fake2, real_labels)

            optimizer_gen.zero_grad()
            loss_G.backward()
            optimizer_gen.step()

        if epoch % 100 == 0:
            print(f"Epoch {epoch}  Loss_G: {loss_G.item():.4f}  Loss_D: {loss_D.item():.4f}")

    generator.eval()
    with torch.no_grad():
        z3 = torch.randn(50000, latent_dim, device=device)
        fake_samples = generator(z3).cpu().numpy().reshape(-1)

    real_np = real_data.numpy().reshape(-1)

    plt.hist(real_np, bins=100, density=True, alpha=0.5, label='Real')
    plt.hist(fake_samples, bins=100, density=True, alpha=0.5, label='Generated')
    plt.legend()
    plt.show()

    x = np.linspace(-4, 4, 400)
    real_kde = gaussian_kde(real_np)
    fake_kde = gaussian_kde(fake_samples)
    plt.plot(x, real_kde(x), label="Real")
    plt.plot(x, fake_kde(x), label="Generated")
    plt.legend()
    plt.show()

if __name__ == '__main__':
    main()
