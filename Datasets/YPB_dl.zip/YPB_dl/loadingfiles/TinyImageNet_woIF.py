import os
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms

# Custom dataset class
class CustomImageDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.samples = []

        # Loop through each class folder
        for label, class_name in enumerate(sorted(os.listdir(root_dir))):
            class_folder = os.path.join(root_dir, class_name)
            if not os.path.isdir(class_folder):
                continue  # skip files that aren’t folders

            # Loop through each image file in this folder
            for filename in os.listdir(class_folder):
                if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                    img_path = os.path.join(class_folder, filename)
                    self.samples.append((img_path, label))

        self.class_names = sorted(os.listdir(root_dir))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, label = self.samples[idx]
        image = Image.open(img_path).convert("RGB")  # Ensure 3 channels

        if self.transform:
            image = self.transform(image)

        return image, label

# ---- Step 2: Define transforms ----
transform = transforms.Compose([
    transforms.Resize((128, 128)),   # Resize all images to 128x128
    transforms.ToTensor()            # Convert to tensor
])
train_dir = "../data/imagenet_subset/train"
test_dir = "../data/imagenet_subset/test"

train_dataset = CustomImageDataset(train_dir, transform=transform)
test_dataset = CustomImageDataset(test_dir, transform=transform)
