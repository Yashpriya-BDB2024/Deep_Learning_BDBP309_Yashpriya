import os
import scipy.io
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms


class Flowers102Dataset(Dataset):
    def __init__(self, root_dir, split='train', transform=None):
        self.root_dir = root_dir
        self.transform = transform

        # Load splits
        setid = scipy.io.loadmat(os.path.join(root_dir, 'setid.mat'))
        labels = scipy.io.loadmat(os.path.join(root_dir, 'imagelabels.mat'))['labels'][0]

        # Map split to correct index array
        if split == 'train':
            idx = setid['trnid'][0]
        elif split == 'val':
            idx = setid['valid'][0]
        elif split == 'test':
            idx = setid['tstid'][0]
        else:
            raise ValueError("split must be 'train', 'val', or 'test'")

        # Build list of (image_path, label)
        self.data = []
        for i in idx:
            img_name = f"image_{i:05d}.jpg"
            img_path = os.path.join(root_dir, 'jpg', img_name)
            label = labels[i - 1] - 1  # zero-based label
            self.data.append((img_path, label))

        print(f"{split.upper()} split: {len(self.data)} samples")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        img_path, label = self.data[idx]
        img = Image.open(img_path).convert('RGB')

        if self.transform:
            img = self.transform(img)

        return img, label

transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor()
])

train_dataset = Flowers102Dataset("../flowers-102", split='train', transform=transform)
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)

images, labels = next(iter(train_loader))
print(f"Batch shape: {images.shape}")
print(f"Labels: {labels[:10]}")
