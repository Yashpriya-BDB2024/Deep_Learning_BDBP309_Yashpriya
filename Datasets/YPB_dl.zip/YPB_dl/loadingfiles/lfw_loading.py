from torchvision import datasets, transforms
from torch.utils.data import DataLoader

# Image transforms
transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor()
])

# Load dataset
dataset = datasets.ImageFolder(root="/Users/sharmishtaganesh/Desktop/DL_Practice_Questions/data/lfw-py/lfw-deepfunneled", transform=transform)

# Create DataLoader
dataloader = DataLoader(dataset, batch_size=32, shuffle=True)

# Check some info
print(f"Total images: {len(dataset)}")
print(f"Total classes: {len(dataset.classes)}")

# Inspect one batch
images, labels = next(iter(dataloader))
print(f"Batch shape: {images.shape}")
print(f"Sample labels: {labels[:10]}")
