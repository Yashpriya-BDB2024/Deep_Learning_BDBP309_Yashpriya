import os
import pandas as pd
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms


class GTSRBDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform

        # Collect all annotation files
        self.data = []
        for class_id in sorted(os.listdir(root_dir)):
            class_path = os.path.join(root_dir, class_id)
            if not os.path.isdir(class_path):
                continue

            csv_path = os.path.join(class_path, f"GT-{class_id}.csv")
            if not os.path.exists(csv_path):
                continue

            df = pd.read_csv(csv_path, sep=';')
            for _, row in df.iterrows():
                img_path = os.path.join(class_path, row['Filename'])
                label = int(row['ClassId'])
                self.data.append((img_path, label))

        print(f"Loaded {len(self.data)} images from {len(os.listdir(root_dir))} classes.")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        img_path, label = self.data[idx]
        image = Image.open(img_path).convert("RGB")

        if self.transform:
            image = self.transform(image)

        return image, label

transform = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.ToTensor(),
])

dataset = GTSRBDataset(root_dir="../gtsrb/GTSRB/Training", transform=transform)
dataloader = DataLoader(dataset, batch_size=32, shuffle=True)

# Inspect a few samples
images, labels = next(iter(dataloader))
print(f"Batch shape: {images.shape}")
print(f"Labels: {labels[:10]}")
