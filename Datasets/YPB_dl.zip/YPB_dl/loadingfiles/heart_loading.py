import torch
from torch.utils.data import Dataset, DataLoader
import pandas as pd

class HeartDiseaseDataset(Dataset):
    def __init__(self, csv_file):
        self.data = pd.read_csv(csv_file)
        self.X = torch.tensor(self.data.drop(columns=['output']).values, dtype=torch.float32)
        self.y = torch.tensor(self.data['output'].values, dtype=torch.float32)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

csv_file = "/Users/sharmishtaganesh/Desktop/DL_Practice_Questions/data/heart.csv"
dataset = HeartDiseaseDataset(csv_file)
dataloader = DataLoader(dataset, batch_size=2, shuffle=True)

for X, y in dataloader:
    print(X.shape, y.shape)
    print(X)
    print(y)
    break
