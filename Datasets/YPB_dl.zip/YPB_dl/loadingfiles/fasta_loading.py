import torch
from torch.utils.data import Dataset, DataLoader, random_split


# ---- Step 1: Parse FASTA ----
def read_fasta(file_path):
    sequences = {}  # dictionary to store {sequence_id: sequence}
    with open(file_path, "r") as f:  # open the FASTA file
        seq_id = None  # variable to store current sequence ID
        for line in f:  # read file line by line
            line = line.strip()  # remove newline characters
            if line.startswith(">"):  # if the line is a header
                seq_id = line[1:]  # extract ID without '>'
                sequences[seq_id] = ""  # initialize empty sequence string
            else:
                sequences[seq_id] += line.upper()  # append sequence (convert to uppercase)
    return sequences  # return dictionary of sequences


# ---- Step 2: One-Hot Encoding ----
# base → integer mapping
base_to_int = {"A": 0, "C": 1, "G": 2, "T": 3}


def one_hot_encode(seq):
    # convert each nucleotide to an integer index (ignore invalid chars)
    seq_tensor = torch.tensor([base_to_int[b] for b in seq if b in base_to_int],
                              dtype=torch.long)

    # one-hot encode to shape (sequence_length, 4)
    one_hot = torch.nn.functional.one_hot(seq_tensor, num_classes=4).float()

    return one_hot  # return tensor


# ---- Step 3: Custom Dataset ----
class DNADataset(Dataset):
    def __init__(self, fasta_file):
        self.data = read_fasta(fasta_file)  # load sequences from FASTA
        self.seq_ids = list(self.data.keys())  # list of all sequence IDs

    def __len__(self):
        return len(self.seq_ids)  # number of sequences in dataset

    def __getitem__(self, idx):
        seq_id = self.seq_ids[idx]  # get sequence ID for index
        seq = self.data[seq_id]  # get actual sequence string
        encoded_seq = one_hot_encode(seq)  # convert to one-hot tensor
        return encoded_seq, seq_id  # return data + identifier


# ---- Step 4: Load Dataset ----
fasta_file = "/data/sample.fasta"  # path to your FASTA file
dataset = DNADataset(fasta_file)  # create the dataset object

print(f"Total sequences: {len(dataset)}")  # print total count

# inspect first item
encoded_seq, seq_id = dataset[0]  # get item at index 0
print("Sequence ID:", seq_id)  # print ID
print("One-hot encoded shape:", encoded_seq.shape)  # print tensor shape
print(encoded_seq[:10])  # print first 10 rows of tensor

# ---- Step 5: 70% Train / 30% Test Split ----
total_samples = len(dataset)  # get dataset size
train_size = int(0.7 * total_samples)  # 70%
test_size = total_samples - train_size  # remaining 30%

train_set, test_set = random_split(dataset, [train_size, test_size])  # split dataset

# ---- Step 6: Create DataLoaders (batch size 2) ----
train_loader = DataLoader(train_set, batch_size=2, shuffle=True)  # training loader
test_loader = DataLoader(test_set, batch_size=2, shuffle=False)  # test loader

print("\nTrain loader batches:", len(train_loader))  # number of batches in train
print("Test loader batches:", len(test_loader))  # number of batches in test)

# ---- Step 7: Print First Batch ----
for batch_seqs, batch_ids in train_loader:  # get first training batch
    print("\nFirst Batch (Sequences Tensor Shape):", batch_seqs.shape)
    print("First Batch IDs:", batch_ids)
    break  # stop after first batch



