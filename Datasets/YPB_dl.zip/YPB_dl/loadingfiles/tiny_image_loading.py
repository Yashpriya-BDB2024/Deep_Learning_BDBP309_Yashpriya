import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader

# ---- Step 1: Define paths ----
train_dir = "../data/imagenet_subset/train"
test_dir = "../data/imagenet_subset/test"

# ---- Step 2: Define transforms ----
transform = transforms.Compose([
    transforms.Resize((128, 128)),   # Resize all images to 128x128
    transforms.ToTensor(),           # Convert to tensor
    transforms.Normalize((0.5,), (0.5,))  # Normalize pixel values
])

# ---- Step 3: Load datasets ----
train_dataset = datasets.ImageFolder(root=train_dir, transform=transform)
test_dataset = datasets.ImageFolder(root=test_dir, transform=transform)

# ---- Step 4: Create data loaders ----
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

images,labels = next(iter(train_loader))
print(images)
print(labels)