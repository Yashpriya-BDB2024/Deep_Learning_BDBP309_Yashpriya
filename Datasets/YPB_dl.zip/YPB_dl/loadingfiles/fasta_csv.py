import torch
from torch.utils.data import Dataset
from Bio import SeqIO
import pandas as pd


class FastaLabelDataset(Dataset):
    """
    A PyTorch Dataset that loads sequences from a FASTA file and labels from a CSV file.

    CSV format:
        id,label
        seq1,0
        seq2,1
    FASTA format:
        >seq1
        ATGCATGCA...
        >seq2
        GCTAGCTAG...
    """

    def __init__(self, fasta_path, csv_path, vocab=None, max_len=None):
        """
        Args:
            fasta_path (str): Path to the FASTA file.
            csv_path (str): Path to the CSV file containing 'id' and 'label' columns.
            vocab (dict, optional): Mapping of characters to integers.
            max_len (int, optional): Maximum sequence length (for truncation/padding).
        """
        self.fasta_dict = {record.id: str(record.seq) for record in SeqIO.parse(fasta_path, "fasta")}
        self.labels_df = pd.read_csv(csv_path)

        # Merge sequences with labels
        self.data = []
        for _, row in self.labels_df.iterrows():
            seq_id, label = row["id"], row["label"]
            seq = self.fasta_dict.get(seq_id)
            if seq:
                self.data.append((seq, label))

        # Default vocabulary: DNA bases (A, C, G, T, N)
        if vocab is None:
            self.vocab = {ch: i + 1 for i, ch in enumerate("ACGT")}
            self.vocab["N"] = 0  # unknown or padding
        else:
            self.vocab = vocab

        self.max_len = max_len

    def __len__(self):
        return len(self.data)

    def encode_seq(self, seq):
        """Convert sequence string into numeric tensor using vocab."""
        encoded = [self.vocab.get(base.upper(), 0) for base in seq]
        if self.max_len:
            if len(encoded) > self.max_len:
                encoded = encoded[:self.max_len]
            else:
                encoded += [0] * (self.max_len - len(encoded))  # pad
        return torch.tensor(encoded, dtype=torch.long)

    def __getitem__(self, idx):
        seq, label = self.data[idx]
        encoded_seq = self.encode_seq(seq)
        label_tensor = torch.tensor(label, dtype=torch.long)

        # Example files
        fasta_path = "sequences.fasta"
        csv_path = "labels.csv"

        # Create dataset
        dataset = FastaLabelDataset(fasta_path, csv_path, max_len=100)

        print("Number of samples:", len(dataset))
        seq, label = dataset[0]
        print("Encoded sequence:", seq)
        print("Label:", label)
        return encoded_seq, label_tensor


# Example files
fasta_path = "sequences.fasta"
csv_path = "labels.csv"

# Create dataset
dataset = FastaLabelDataset(fasta_path, csv_path, max_len=100)

print("Number of samples:", len(dataset))
seq, label = dataset[0]
print("Encoded sequence:", seq)
print("Label:", label)
