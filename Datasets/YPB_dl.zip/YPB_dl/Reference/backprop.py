import numpy as np

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(a):
    return a * (1 - a)

def relu(x):
    return np.maximum(0, x)

def relu_derivative(a):
    return np.where(a > 0, 1, 0)

def identity(x):
    return x

def identity_derivative(a):
    return np.ones_like(a)

def softmax(x):
    e_x = np.exp(x - np.max(x))
    return e_x / np.sum(e_x, axis=1, keepdims=True)

activation_funcs = {
    "sigmoid": (sigmoid, sigmoid_derivative),
    "relu": (relu, relu_derivative),
    "identity": (identity, identity_derivative),
    "softmax": (softmax, None)  # derivative handled differently
}

class NeuralNetwork:
    def __init__(self, layer_sizes, activations, use_bias=True):
        self.num_layers = len(layer_sizes) - 1
        self.layer_sizes = layer_sizes
        self.activations = activations
        self.use_bias = use_bias

        # Initialize weights and biases
        self.W = [np.random.randn(layer_sizes[i], layer_sizes[i+1]) for i in range(self.num_layers)]
        self.b = [np.zeros((1, layer_sizes[i+1])) if use_bias else None for i in range(self.num_layers)]

    def forward(self, X):
        self.a = [X]  # activations
        self.z = []    # pre-activation values
        for i in range(self.num_layers):
            z = self.a[-1] @ self.W[i]
            if self.use_bias:
                z += self.b[i]
            self.z.append(z)
            act_func = activation_funcs[self.activations[i]][0]
            self.a.append(act_func(z))
        return self.a[-1]

    def compute_loss(self, y_true, loss_type="mse"):
        self.y_true = y_true
        if loss_type == "mse":
            self.loss = 0.5 * np.sum((self.a[-1] - y_true)**2)
        elif loss_type == "cross_entropy":
            # only for softmax output
            self.loss = -np.sum(y_true * np.log(self.a[-1] + 1e-8))
        else:
            raise ValueError("Unknown loss type")
        return self.loss

    def backward(self, loss_type="mse"):
        grads_W = [np.zeros_like(W) for W in self.W]
        grads_b = [np.zeros_like(b) if self.use_bias else None for b in self.b]

        # -----------------
        # Output layer delta
        # -----------------
        if self.activations[-1] == "softmax" and loss_type == "cross_entropy":
            delta = self.a[-1] - self.y_true
        else:
            delta = (self.a[-1] - self.y_true) * activation_funcs[self.activations[-1]][1](self.a[-1])

        for i in reversed(range(self.num_layers)):
            grads_W[i] = self.a[i].T @ delta
            if self.use_bias:
                grads_b[i] = np.sum(delta, axis=0, keepdims=True)
            if i > 0:
                delta = delta @ self.W[i].T
                delta = delta * activation_funcs[self.activations[i-1]][1](self.a[i])

        return grads_W, grads_b

    def update_weights(self, grads_W, grads_b, lr=0.1):
        for i in range(self.num_layers):
            self.W[i] -= lr * grads_W[i]
            if self.use_bias:
                self.b[i] -= lr * grads_b[i]

def get_layer_sizes_and_activations():
    X_size = int(input("Enter input size (number of features): "))
    num_hidden = int(input("Enter number of hidden layers (0 for none): "))
    layer_sizes = [X_size]
    activations = []

    for i in range(num_hidden):
        neurons = int(input(f"Number of neurons in hidden layer {i+1}: "))
        layer_sizes.append(neurons)
        act = input(f"Activation for hidden layer {i+1} (sigmoid/relu/identity): ").strip()
        activations.append(act)

    out_neurons = int(input("Number of neurons in output layer: "))
    layer_sizes.append(out_neurons)
    out_act = input("Activation for output layer (softmax/sigmoid/identity): ").strip()
    activations.append(out_act)

    return layer_sizes, activations

def get_inputs_and_weights(layer_sizes, use_bias=True):
    choice = input("Choose input type:\n1: Random\n2: Manual\nEnter choice: ").strip()
    if choice == "1":
        X = np.random.randn(1, layer_sizes[0])
        print("Random input X:", X)
    else:
        vals = list(map(float, input(f"Enter {layer_sizes[0]} input values separated by space: ").split()))
        X = np.array(vals).reshape(1, -1)

    W = []
    b = []
    for i in range(len(layer_sizes)-1):
        n_in, n_out = layer_sizes[i], layer_sizes[i+1]
        choice_w = input(f"Do you want to enter matrix for layer {i+1} weights? (Y/N): ").strip().upper()
        if choice_w == "Y":
            vals = list(map(float, input(f"Enter {n_in*n_out} values row-wise: ").split()))
            W.append(np.array(vals).reshape(n_in, n_out))
        else:
            W.append(np.random.randn(n_in, n_out))

        if use_bias:
            choice_b = input(f"Do you want to enter biases for layer {i+1}? (Y/N): ").strip().upper()
            if choice_b == "Y":
                vals = list(map(float, input(f"Enter {n_out} bias values: ").split()))
                b.append(np.array(vals).reshape(1, n_out))
            else:
                b.append(np.zeros((1, n_out)))
        else:
            b.append(None)

    return X, W, b

def main():
    use_bias = True
    layer_sizes, activations = get_layer_sizes_and_activations()
    X, W_manual, b_manual = get_inputs_and_weights(layer_sizes, use_bias=use_bias)
    y_true = np.array(list(map(float, input(f"Enter {layer_sizes[-1]} target values separated by space: ").split()))).reshape(1, -1)

    nn = NeuralNetwork(layer_sizes, activations, use_bias=use_bias)
    nn.W = W_manual
    nn.b = b_manual

    # Forward
    y_pred = nn.forward(X)
    print("\nPrediction:\n", y_pred)

    # Loss
    loss = nn.compute_loss(y_true, loss_type="mse")
    print("Loss:", loss)

    # Backward
    grads_W, grads_b = nn.backward(loss_type="mse")
    print("\nGradients for each layer:")
    for i in range(nn.num_layers):
        print(f"Layer {i+1} dW:\n", grads_W[i])
        if use_bias:
            print(f"Layer {i+1} db:\n", grads_b[i])

    # Optional: update weights
    # nn.update_weights(grads_W, grads_b, lr=0.1)

if __name__ == "__main__":
    main()
