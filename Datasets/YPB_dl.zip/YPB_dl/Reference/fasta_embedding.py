# =============================================================
# generate_dna_embeddings.py
# Generate embedding vectors for DNA sequences (sample.fasta)
# =============================================================

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from Bio import SeqIO
import pandas as pd
import numpy as np
import os

# -----------------------------
# 1️⃣ DNA Vocabulary & Settings
# -----------------------------
DNA_VOCAB = {'A': 1, 'C': 2, 'G': 3, 'T': 4, 'N': 5, '<PAD>': 0}
MAX_SEQ_LENGTH = 100

# -----------------------------
# 2️⃣ Load FASTA Sequences
# -----------------------------
def load_dna_sequences(fasta_file):
    sequences = {}
    for record in SeqIO.parse(fasta_file, "fasta"):
        sequences[record.id] = str(record.seq).upper()
    return sequences


# -----------------------------
# 3️⃣ Encode DNA to numbers
# -----------------------------
def encode_sequence(seq, max_len=MAX_SEQ_LENGTH):
    seq = seq[:max_len]
    encoded = [DNA_VOCAB.get(base, DNA_VOCAB['N']) for base in seq]
    padding = [DNA_VOCAB['<PAD>']] * (max_len - len(encoded))
    return encoded + padding


# -----------------------------
# 4️⃣ Dataset Class
# -----------------------------
class DNADataset(Dataset):
    def __init__(self, sequences):
        self.ids = list(sequences.keys())
        self.sequences = sequences

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, idx):
        seq_id = self.ids[idx]
        seq = self.sequences[seq_id]
        encoded_seq = encode_sequence(seq)
        return {
            'id': seq_id,
            'sequence': torch.LongTensor(encoded_seq)
        }


# -----------------------------
# 5️⃣ Simple LSTM Embedding Model
# -----------------------------
class DNAEmbeddingModel(nn.Module):
    def __init__(self, vocab_size, embedding_dim=32, hidden_dim=64, num_layers=1, dropout=0.2):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, batch_first=True,
                            bidirectional=True, dropout=dropout if num_layers > 1 else 0)
        self.fc = nn.Linear(hidden_dim * 2, hidden_dim)
        self.relu = nn.ReLU()

    def forward(self, x):
        emb = self.embedding(x)
        out, _ = self.lstm(emb)
        pooled, _ = torch.max(out, dim=1)
        features = self.relu(self.fc(pooled))
        return features  # (batch_size, hidden_dim)


# -----------------------------
# 6️⃣ Generate & Save Embeddings
# -----------------------------
def generate_embeddings(fasta_file, output_csv="dna_embeddings.csv"):
    if not os.path.exists(fasta_file):
        raise FileNotFoundError(f"{fasta_file} not found!")

    print(f"📂 Loading sequences from {fasta_file} ...")
    sequences = load_dna_sequences(fasta_file)
    dataset = DNADataset(sequences)
    dataloader = DataLoader(dataset, batch_size=4, shuffle=False)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = DNAEmbeddingModel(vocab_size=len(DNA_VOCAB)).to(device)
    model.eval()

    print("🧠 Generating embeddings ...")
    all_ids, all_embeddings = [], []

    with torch.no_grad():
        for batch in dataloader:
            seqs = batch['sequence'].to(device)
            embs = model(seqs).cpu().numpy()
            all_ids.extend(batch['id'])
            all_embeddings.extend(embs)

    df = pd.DataFrame(all_embeddings, index=all_ids)
    df.to_csv(output_csv)
    print(f"✅ Saved embeddings to: {output_csv}")
    print(f"🧩 Embedding shape per sequence: {len(all_embeddings[0])} dimensions")


# -----------------------------
# 7️⃣ Run the script
# -----------------------------
if __name__ == "__main__":
    fasta_file = "sample.fasta"   # Your provided FASTA file
    output_csv = "dna_embeddings.csv"
    generate_embeddings(fasta_file, output_csv)
