import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

def prepare_dataloader(dataset, batch_size=64, shuffle=True):
    """Creates a DataLoader for a given dataset."""
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle)

def detect_dataset_info(dataset):
    """Automatically detect input size (flattened) and number of classes."""
    sample_X, sample_y = dataset[0]
    input_size = sample_X.numel()  # total features after flattening
    if hasattr(dataset, "classes"):
        num_classes = len(dataset.classes)
    else:
        labels = torch.tensor([y for _, y in dataset])
        num_classes = len(torch.unique(labels))
    return input_size, num_classes

def auto_hidden_sizes(input_size, output_size):
    """Generates hidden layer sizes reducing by half until smaller than 2*output."""
    hidden = []
    size = input_size
    while size > 2 * output_size:
        size = max(size // 2, output_size + 1)
        hidden.append(size)
    return hidden

class NeuralNetwork(nn.Module):
    """Fully connected feed-forward network."""

    def __init__(self, input_size, num_classes, hidden_sizes=None):
        super().__init__()
        if hidden_sizes is None:
            hidden_sizes = auto_hidden_sizes(input_size, num_classes)
        layers = [nn.Flatten()]  # flatten input tensor
        in_features = input_size
        for h in hidden_sizes:
            layers.append(nn.Linear(in_features, h))
            layers.append(nn.ReLU())
            in_features = h
        layers.append(nn.Linear(in_features, num_classes))  # output layer
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)

def train(dataloader, model, loss_fn, optimizer, device):
    """Train model for one epoch."""
    model.train()
    for X, y in dataloader:
        X, y = X.to(device), y.to(device)
        pred = model(X)
        loss = loss_fn(pred, y)
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

def test(dataloader, model, loss_fn, device):
    """Evaluate model on test data."""
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for X, y in dataloader:
            X, y = X.to(device), y.to(device)
            pred = model(X)
            test_loss += loss_fn(pred, y).item()
            correct += (pred.argmax(1) == y).type(torch.float).sum().item()
    test_loss /= len(dataloader)
    correct /= len(dataloader.dataset)
    print(f"Test Accuracy: {100 * correct:.2f}%, Avg Loss: {test_loss:.4f}")

def run_pipeline(train_dataset, test_dataset, epochs=5, batch_size=None):
    """Train and evaluate the FFN model on any dataset."""
    device = "cuda" if torch.cuda.is_available() else "cpu"

    if batch_size is None:
        batch_size = min(64, max(1, len(train_dataset) // 10))  # auto batch size

    # Create dataloaders
    train_loader = prepare_dataloader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = prepare_dataloader(test_dataset, batch_size=batch_size, shuffle=False)

    # Detect input/output sizes
    input_size, num_classes = detect_dataset_info(train_dataset)
    print(f"Input size: {input_size}, Number of classes: {num_classes}")

    # Initialize model, loss, optimizer
    model = NeuralNetwork(input_size, num_classes).to(device)
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    # Train and test for given epochs
    for t in range(epochs):
        print(f"\nEpoch {t + 1}")
        train(train_loader, model, loss_fn, optimizer, device)
        test(test_loader, model, loss_fn, device)

    # Save model
    torch.save(model.state_dict(), "model.pth")
    print("Saved model to model.pth")
    return model, device

def predict(model, dataset, index=0, device="cpu"):
    """Predict single sample from dataset."""
    model.eval()
    x, y = dataset[index]
    x = x.to(device)
    with torch.no_grad():
        pred = model(x)
    predicted_class = pred.argmax(0).item()
    if hasattr(dataset, "classes"):
        return dataset.classes[predicted_class], dataset.classes[y]
    else:
        return predicted_class, y

def main():
    transform = transforms.ToTensor()

    # Replace these with any dataset
    train_data = datasets.FashionMNIST(root="data", train=True, download=True, transform=transform)
    test_data = datasets.FashionMNIST(root="data", train=False, download=True, transform=transform)

    # Run automatic pipeline
    model, device = run_pipeline(train_data, test_data, epochs=3)

    # Test prediction on first sample
    predicted, actual = predict(model, test_data, index=0, device=device)
    print(f"\nSample 0 - Predicted: {predicted}, Actual: {actual}")

if __name__ == "__main__":
    main()
