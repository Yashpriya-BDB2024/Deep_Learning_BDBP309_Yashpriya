#
# import torch
# from torchvision import datasets, transforms
#
# # Common transform — convert to tensor and normalize
# transform = transforms.Compose([
#     transforms.ToTensor()
# ])
#
# # List of torchvision datasets to test
# DATASETS = {
#     "CIFAR10": lambda: datasets.CIFAR10(root="../data", train=True, download=True, transform=transform),
#     "EMNIST": lambda: datasets.EMNIST(root="../data", split="byclass", train=True, download=True, transform=transform),
#     "FashionMNIST": lambda: datasets.FashionMNIST(root="../data", train=True, download=True, transform=transform),
#     "MNIST": lambda: datasets.MNIST(root="../data", train=True, download=True, transform=transform),
#     "Caltech101": lambda: datasets.Caltech101(root="../data", download=True, transform=transform),
#     "Flowers102": lambda: datasets.Flowers102(root="../data", download=True, transform=transform),
#     "LFW": lambda: datasets.LFWPeople(root="../data", download=True, transform=transform),
#     "GTSRB": lambda: datasets.GTSRB(root="../data", split="train", download=True, transform=transform),
# }
#
# print("\n=== Torchvision Dataset Availability Check ===\n")
#
# for name, loader in DATASETS.items():
#     try:
#         dataset = loader()
#         print(f"{name} loaded successfully.")
#         print(f"   Total samples: {len(dataset)}")
#
#         # Inspect a few samples
#         img, label = dataset[0]
#         print(f"   Image shape: {img.shape}")
#         print(f"   Label type/value: {type(label)}, {label}\n")
#
#     except Exception as e:
#         print(f"{name} failed to load. Error: {e}\n")



"""
====================================================
DATASET LOADER REFERENCE SCRIPT
====================================================
Author : Shruthi
Purpose: Quick reference for loading all major datasets
         (Image / Text / Sequence / Tabular)
         for Deep Learning Lab & Exam.

Each dataset is pre-downloaded under ~/data/
This script demonstrates how to load, inspect,
and prepare each one with correct transforms.
====================================================
"""

import os
import torch
import torchvision

from torchvision import datasets, transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
from PIL import Image
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from Bio import SeqIO

# ============================================================
# 13️⃣ Tiny ImageNet (ImageNet Subset)
# - 200 classes, 64x64 images
# ============================================================
print("\n=== Tiny ImageNet ===")

from torchvision import datasets, transforms
import os

data_dir = os.path.expanduser("~/data/imagenet_subset")

transform_tiny_imagenet = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
])

train_dir = os.path.join(data_dir, "train")
test_dir = os.path.join(data_dir, "test")

tiny_imagenet_train = datasets.ImageFolder(root=train_dir, transform=transform_tiny_imagenet)
tiny_imagenet_test = datasets.ImageFolder(root=test_dir, transform=transform_tiny_imagenet)

print(f"TinyImageNet → Train: {len(tiny_imagenet_train)} | Test: {len(tiny_imagenet_test)}")
print("Classes:", tiny_imagenet_train.classes[:5], "...")
print("Example shape:", tiny_imagenet_train[0][0].shape)


# ============================================================
# 1️⃣ MNIST / FashionMNIST / EMNIST
# - Handwritten digits / fashion items / letters
# ============================================================
print("\n=== MNIST / FashionMNIST / EMNIST ===")

transform_basic = transforms.Compose([transforms.ToTensor()])

# MNIST
mnist_train = datasets.MNIST(root="~/data", train=True, download=False, transform=transform_basic)
mnist_test = datasets.MNIST(root="~/data", train=False, download=False, transform=transform_basic)
print(f"MNIST → Train: {len(mnist_train)} | Test: {len(mnist_test)}, Image shape: {mnist_train[0][0].shape}")

# FashionMNIST
fashion_train = datasets.FashionMNIST(root="~/data", train=True, download=False, transform=transform_basic)
fashion_test = datasets.FashionMNIST(root="~/data", train=False, download=False, transform=transform_basic)
print(f"FashionMNIST → Train: {len(fashion_train)} | Test: {len(fashion_test)}, Image shape: {fashion_train[0][0].shape}")

# EMNIST (byclass = digits + upper/lowercase letters)
emnist_train = datasets.EMNIST(root="~/data", split="byclass", train=True, download=False, transform=transform_basic)
emnist_test = datasets.EMNIST(root="~/data", split="byclass", train=False, download=False, transform=transform_basic)
print(f"EMNIST → Train: {len(emnist_train)} | Test: {len(emnist_test)}, Image shape: {emnist_train[0][0].shape}")


# ============================================================
# 2️⃣ CIFAR-10
# - Small color image dataset (10 classes)
# ============================================================
print("\n=== CIFAR-10 ===")

transform_cifar = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

cifar_train = datasets.CIFAR10(root="~/data", train=True, download=False, transform=transform_cifar)
cifar_test = datasets.CIFAR10(root="~/data", train=False, download=False, transform=transform_cifar)
print(f"CIFAR-10 → Train: {len(cifar_train)} | Test: {len(cifar_test)}, Image shape: {cifar_train[0][0].shape}")


# ============================================================
# 3️⃣ Caltech-101
# - Object categories (101 classes)
# ============================================================
print("\n=== Caltech-101 ===")

transform_caltech = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])

caltech_root = os.path.expanduser("~/data/")
caltech = datasets.Caltech101(root=caltech_root, download=False, transform=transform_caltech)
print(f"Caltech-101 loaded: {len(caltech)} samples, Example shape: {caltech[0][0].shape}")


# ============================================================
# 4️⃣ Flowers-102
# - Flower image dataset (102 classes)
# ============================================================
print("\n=== Flowers-102 ===")

transform_flowers = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor()
])

flowers = datasets.Flowers102(root="~/data", download=False, transform=transform_flowers)
print(f"Flowers-102 loaded: {len(flowers)} samples, Example shape: {flowers[0][0].shape}")


## ============================================================
# 5️⃣ LFW (Labeled Faces in the Wild)
# - Face recognition dataset (manual version)
# ============================================================
print("\n=== LFW (Labeled Faces in the Wild) ===")

transform_lfw = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor()
])

# Path to your manually downloaded folder
lfw_root = os.path.expanduser("~/data/lfw-py/lfw-deepfunneled")

# Use ImageFolder since you already have the images organized by name folders
lfw_dataset = torchvision.datasets.ImageFolder(
    root=lfw_root,
    transform=transform_lfw
)

# Split manually into train/test (e.g., 80/20)
train_size = int(0.8 * len(lfw_dataset))
test_size = len(lfw_dataset) - train_size
lfw_train, lfw_test = torch.utils.data.random_split(lfw_dataset, [train_size, test_size])

print(f"LFW → Train: {len(lfw_train)} | Test: {len(lfw_test)}, Image shape: {lfw_train[0][0].shape}")


# ============================================================
# 6️⃣ GTSRB (Traffic Sign Recognition)
# ============================================================
print("\n=== GTSRB (Traffic Sign Recognition) ===")

transform_gtsrb = transforms.Compose([
    transforms.Resize((48, 48)),
    transforms.ToTensor()
])

gtsrb_train = datasets.GTSRB(
    root=os.path.expanduser("~/data/gtsrb"),
    split="train",
    download=False,
    transform=transform_gtsrb
)

print(f"GTSRB loaded: {len(gtsrb_train)} training samples, Example shape: {gtsrb_train[0][0].shape}")


# ============================================================
# 7️⃣ FER-2013 (Facial Emotion Recognition)
# ============================================================
print("\n=== FER-2013 (Facial Emotion Recognition) ===")

transform_fer = transforms.Compose([
    transforms.Resize((48, 48)),
    transforms.ToTensor()
])

fer_train = ImageFolder(root="~/data/Fer-2013/train", transform=transform_fer)
fer_test = ImageFolder(root="~/data/Fer-2013/test", transform=transform_fer)
print(f"FER-2013 → Train: {len(fer_train)} | Test: {len(fer_test)}, Classes: {fer_train.classes}")


# ============================================================
# 8️⃣ Flickr8k (Image Captioning)
# ============================================================
print("\n=== Flickr8k (Image Captioning) ===")

captions_file = os.path.expanduser("~/data/flicker8k/captions.txt")
image_folder = os.path.expanduser("~/data/flicker8k/Images/")

if os.path.exists(captions_file):
    try:
        # Read as CSV (comma-separated, no header)
        captions = pd.read_csv(captions_file)
        captions.columns = ["image", "caption"]  # Ensure column names

        print(f"Flickr8k loaded: {len(captions)} caption-image pairs")

        # Check if image files exist
        first_image = None
        for _, row in captions.iterrows():
            img_path = os.path.join(image_folder, row["image"])
            if os.path.exists(img_path):
                first_image = img_path
                caption_text = row["caption"]
                break

        if first_image:
            from PIL import Image

            img = Image.open(first_image).convert("RGB")
            print(f"✅ Example image found: {os.path.basename(first_image)}")
            print(f"Caption: {caption_text}")
            print(f"Image size: {img.size}")
        else:
            print("⚠️ No matching image files found in Images/ directory.")
    except Exception as e:
        print("⚠️ Error reading Flickr8k captions:", e)
else:
    print("⚠️ Flickr8k captions.txt not found. Skipping...")

# ============================================================
# 9️⃣ Heart.csv (Tabular Dataset)
# ============================================================
print("\n=== Heart.csv (Tabular Data) ===")

csv_path = os.path.expanduser("~/data/heart.csv")

if os.path.exists(csv_path):
    try:
        data = pd.read_csv(csv_path)
        print(f"✅ Loaded Heart dataset with shape: {data.shape}")
        print(f"Columns: {list(data.columns)}")

        # Handle different possible target column names
        target_col = None
        for col in ["target", "output", "Outcome", "Target"]:
            if col in data.columns:
                target_col = col
                break

        if target_col is None:
            raise KeyError("❌ No target column ('target' or 'output') found in CSV!")

        # Split into features and labels
        X = data.drop(target_col, axis=1)
        y = data[target_col]

        # Standardize numeric features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        # Train-test split
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y, test_size=0.2, random_state=42
        )

        # Convert to PyTorch tensors
        X_train = torch.tensor(X_train, dtype=torch.float32)
        y_train = torch.tensor(y_train.values, dtype=torch.long)

        print(f"Heart.csv → Train: {X_train.shape[0]} samples, {X_train.shape[1]} features")
        print(f"✅ Target column used: '{target_col}'")

    except Exception as e:
        print(f"⚠️ Error loading Heart.csv: {e}")
else:
    print("⚠️ Heart.csv not found. Skipping...")



# ============================================================
# 🔟 sample.fasta (Sequence Data)
# ============================================================
print("\n=== sample.fasta (Sequence Data) ===")

fasta_path = os.path.expanduser("~/data/sample.fasta")
if os.path.exists(fasta_path):
    for record in SeqIO.parse(fasta_path, "fasta"):
        print(f"Sequence ID: {record.id}")
        print(f"Sequence Length: {len(record.seq)}")
        break  # print only first sequence
else:
    print("⚠️ sample.fasta not found. Skipping...")


# ============================================================
# ✅ Summary
# ============================================================
print("\nAll available datasets successfully inspected.")
print("You can now use them for CNN / RNN / Transformer models in PyTorch.")
