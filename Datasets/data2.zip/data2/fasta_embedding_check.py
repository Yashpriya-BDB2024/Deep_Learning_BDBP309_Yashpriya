from Bio import SeqIO
import pandas as pd

# === 1. Load FASTA headers ===
fasta_file = "sample.fasta"
fasta_ids = [record.id for record in SeqIO.parse(fasta_file, "fasta")]

# === 2. Load Embedding CSV ===
embedding_file = "dna_embeddings.csv"
emb_df = pd.read_csv(embedding_file, index_col=0)
embedding_ids = emb_df.index.tolist()

# === 3. Compare ===
print("FASTA Sequences:", len(fasta_ids))
print("Embeddings:", len(embedding_ids))

# Missing in embedding file
missing_in_embedding = set(fasta_ids) - set(embedding_ids)
if missing_in_embedding:
    print("Missing in embedding file:", missing_in_embedding)
else:
    print("All FASTA sequences are in embedding file")

# Extra in embedding file
extra_in_embedding = set(embedding_ids) - set(fasta_ids)
if extra_in_embedding:
    print("Extra rows in embedding file:", extra_in_embedding)
else:
    print("No extra rows in embedding file")

# === 4. Optional: sanity preview ===
print("\n--- Sample Comparison ---")
for seq_id in fasta_ids[:3]:  # just first few
    seq = next(SeqIO.parse(fasta_file, "fasta"))
    print(f"{seq_id}: embedding vector length = {len(emb_df.loc[seq_id])}")
